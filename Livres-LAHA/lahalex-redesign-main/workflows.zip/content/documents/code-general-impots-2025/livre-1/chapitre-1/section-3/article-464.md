Article 464 :
1) Toute personne autorisée à représenter un contribuable remplit les déclarations d’impôt, présente les états financiers, paye les impôts et se conforme à toutes les obligations imposées au contribuable.
2) Les personnes visées au présent article sont :
1) le tuteur, le curateur ou toute autre personne qui a la garde d’un mineur ou
de toute autre personne privée de capacité légale ;
2) l’administrateur légal ou judiciaire d’un bien foncier ou d’un legs, ou les
héritiers de ce bien ;
3) le propriétaire d’une entreprise ;
3) les membres d’un partenariat dont la responsabilité est illimitée ;
3) le président, les gérants, l’administrateur ou tout autre représentant d’une
société ou de toute autre personne morale ;
6) le  représentant  d’une  société  ou  de  toute  autre  personne  morale  en
liquidation ;
7) toute autre personne mandatée pour représenter ou assister le contribuable.
3) Toute personne visée aux points a, b, e, f ou g du paragraphe 2 ci-dessus, est tenue
de communiquer la nouvelle compétence ou désignation au directeur général des impôts dans le délai de quinze (15) jours qui suit ladite compétence ou désignation.
4) Les personnes visées au point g du paragraphe 2 ci-dessus doivent justifier d’un
mandat régulier dûment enregistré. La production d’un mandat n’est pas exigée d’un avocat régulièrement inscrit au barreau et constitué à cet effet.