Article 181 :
1) Les entreprises soumises à la taxe professionnelle synthétique peuvent opter pour l’impôt sur les bénéfices d’affaires sur demande expresse adressée à tout moment au service des impôts compétent.
2) Ce service est tenu de notifier l’agrément ou le refus au contribuable dans les huit
8) jours de la demande. Le défaut de réponse équivaut à une acceptation.
2) L’option  prend  effet  à  compter  du  premier  jour  du  mois  suivant  celui  de
l’acceptation de la demande.
4) L’option est irrévocable.