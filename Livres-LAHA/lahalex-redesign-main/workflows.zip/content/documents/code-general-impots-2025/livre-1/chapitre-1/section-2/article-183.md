Article 183 :
(Modifié par la loi de finances pour 2024) 1) La taxe professionnelle synthétique est déterminée par application au montant des recettes annuelles, d’un taux de 5%.
2) Le montant de l’impôt ne peut être inférieur à dix mille (10 000) francs CFA.
2) Il est perçu en sus du montant de l’impôt, un prélèvement d’une redevance de
0. FCFA au profit de la société nationale de radiodiffusion et télévision.
2) La taxe est due par commune et par établissement.