Article 241 :
Le taux de la taxe sur la valeur ajoutée est fixé à 18%.