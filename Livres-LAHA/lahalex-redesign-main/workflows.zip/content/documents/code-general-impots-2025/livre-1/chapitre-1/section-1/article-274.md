Article 274 :
1) Il est institué une taxe sur les produits spécifiques, applicable sur certains produits  importés  ou  fabriqués  en  République  du  Bénin  et  livrés  à  la  consommation intérieure.
2) La taxe frappe toutes importations ou cessions des produits listés par l’article 277 du
présent code effectuées à titre onéreux ou à titre gratuit et réalisées en droit ou en fait aux conditions de livraison en République du Bénin.
3) Sont assimilés à des cessions, les prélèvements effectués par le producteur pour ses
besoins propres ou l’affectation à la consommation.