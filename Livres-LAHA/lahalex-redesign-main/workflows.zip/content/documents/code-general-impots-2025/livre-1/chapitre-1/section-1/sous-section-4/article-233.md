Article 233 :
1) Le lieu d’une livraison de bien est réputé situé en République du Bénin dès lors que le bien s’y trouve :
1) au moment de la livraison ;
1) ou, en cas d’expédition du bien, au moment du départ de l’expédition ou
du transport à destination de l’acquéreur.
2) Lorsque le lieu de départ de l’expédition ou du transport du bien se trouve en
dehors du territoire national, le lieu de l’importation est réputé se situer en République du Bénin.
3) Si le bien fait l’objet d’une installation ou d’un montage par le fournisseur ou pour
son compte, le lieu de la livraison est réputé se situer à l’endroit où est fait l’installation ou le montage.