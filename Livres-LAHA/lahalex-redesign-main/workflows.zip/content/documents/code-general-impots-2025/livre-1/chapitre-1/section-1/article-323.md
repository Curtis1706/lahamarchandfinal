Article 323 :
1) La perception des droits est réglée d’après la forme extérieure des actes ou la substance de leurs dispositions, sans égard à leur validité, ni aux causes quelconques de résolution ou d’annulation ultérieures.
2) Si les sommes et valeurs ne sont pas déterminées dans un acte ou un jugement
donnant  lieu  au  droit  proportionnel,  les  parties  sont  tenues  d’y  suppléer,  avant l’enregistrement, par une déclaration estimative détaillée, certifiée et signée au pied de l’acte.
3) En  ce  qui  concerne  les  mutations  et  conventions  affectées  d’une  condition
suspensive, les tarifs applicables et les valeurs imposables sont déterminés en se plaçant à la date de la réalisation de la condition.