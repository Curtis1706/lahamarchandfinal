Article 184 :
1) Les entreprises soumises à la taxe professionnelle synthétique doivent souscrire, au plus tard le 30 avril de chaque année, au service des impôts territorialement compétent, une déclaration relative à l’exercice précédent.
2) Cette déclaration, souscrite en trois (3) exemplaires, accompagnée des états
financiers, doit comporter :
1) les nom, prénoms ou raison sociale ;
1) le numéro de l’identifiant fiscal unique ;
1) la nature de la ou des activité(s) ;
1) les références de localisation (ville, quartier, îlot, parcelle, rue, entrée, numéro
de porte) ;
5) le numéro de la boîte postale ;
5) le numéro de téléphone et, le cas échéant, l’adresse électronique ;
7) la liste des cinq (5) principaux fournisseurs et cinq (5) principaux clients de
l’entreprise ;
8) le  montant  des  achats  de  l’année  précédente,  ventilé  par  nature  des
marchandises achetées ;
9) le montant des recettes annuelles et du chiffre d’affaires par établissement ;
9) le montant annuel des loyers professionnels.