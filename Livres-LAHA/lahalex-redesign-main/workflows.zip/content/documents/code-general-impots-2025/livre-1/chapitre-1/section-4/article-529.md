Article 529 :
1) Le droit d’enquête est exercé par les agents des impôts ayant au moins le grade d’inspecteur des impôts ou des agents compétents habilités par la personne responsable des enquêtes fiscales sur autorisation du directeur général des impôts. L’agent enquêteur doit être assermenté et porteur de sa commission.
Lorsque  l’enquête  requiert  des  connaissances  techniques  particulières, l’administration fiscale peut faire appel aux experts mandatés par le directeur général des impôts.
2) Le droit d’enquête s’exerce sur place chez l’assujetti ou, sur convocation, dans les
locaux de l’administration.
3) Lors de la première intervention ou convocation au titre du droit d’enquête, un avis
d’enquête est remis à l’assujetti ou à son représentant lorsqu’il s’agit d’une personne morale.
En l’absence de ces deux personnes, l’avis est remis à la personne qui reçoit les enquêteurs, et un procès-verbal est établi immédiatement. Il est signé par les agents de l’administration et par la personne qui a reçu l’avis d’enquête. En cas de refus de signer, mention en est faite au procès-verbal. Une copie de celui-ci est remise à cette personne ; une autre est transmise à l’intéressé ou à son représentant.
4) La durée des interventions sur place dans le cadre du droit d’enquête ne peut
excéder trois (3) jours ouvrables.