Article 255 :
1) Les demandes de remboursement de la taxe sur la valeur ajoutée doivent être instruites dans le délai d’un mois à compter de leur date de réception.
2) Celles qui sont reconnues fondées après instruction par les services des impôts
donnent lieu à l’établissement d’un certificat de détaxe approuvé par le ministre chargé des finances. Celui-ci peut déléguer son pouvoir au directeur général des impôts.
3) Le certificat de détaxe peut être remis par le bénéficiaire en paiement de la taxe
sur la valeur ajoutée due au titre d’autres opérations taxables. Il peut être également transféré par endos à un commissionnaire en douane pour être utilisé aux mêmes fins.
4) Le cas échéant, le certificat de détaxe peut être remis en paiement d’autres
impôts d’État dus par le bénéficiaire, à l’exception des retenues à la source.