Article  52 :
1)  Lorsqu’un  contribuable  estime  pouvoir  apporter  la  preuve  que  le montant total de l’impôt sur les sociétés, auquel il doit être soumis au titre d’une année, doit être inférieur au montant total des acomptes dont il est redevable, il peut déposer, un (1) mois avant l’échéance de l’acompte du trimestre considéré, une demande en réduction des versements d’acomptes au directeur général des impôts.
2) La demande doit exposer les motifs pour lesquels le contribuable estime que le
montant de l’impôt sur les sociétés de l’année en cours doit être inférieur au montant des acomptes dont il est redevable pour ladite année.
3) Le directeur général des impôts peut lui délivrer, après vérification, une autorisation
de réduction de l’acompte ou dispense d’acompte, quinze (15) jours au moins avant la date d’exigibilité de l’acompte du trimestre de la demande. Copie de cette autorisation ou dispense est transmise au service chargé du recouvrement.
4) Le directeur général des impôts est habilité à refuser la demande en réduction
d’acomptes lorsque le contribuable ne s’est pas intégralement acquitté de ses dettes fiscales à la date de la demande.
5) Lorsque le directeur général des impôts estime avoir en sa possession les éléments
suffisants  pour  opposer  un  refus  nettement  motivé  à  une  demande  en  réduction d’acomptes, soit en application du paragraphe 4 du présent article, soit pour toutes autres raisons, il notifie ce refus par lettre dans les quinze (15) jours de la réception de la demande. Passé  ce  délai,  la  demande  du  contribuable  est  considérée  comme  acceptée tacitement.
6) Lorsque le directeur général des impôts a donné son accord formel ou tacite à la
demande  en  réduction  d’acomptes  présentée  par  un  contribuable,  ce  dernier  doit acquitter ses acomptes de l’année en cours aux dates et selon les pourcentages prévus à l’article 51 du présent code, chaque acompte étant alors calculé sur le montant des impôts dont il s’estime redevable, tel que précisé dans sa demande.
7) Lorsque  la  déclaration  faite  pour  obtenir  une  réduction  des  versements
d’acomptes est reconnue inexacte de plus du dixième, le contribuable est passible d’une pénalité égale à 20% de la différence constatée.
8) Aux fins du présent article, le directeur général des impôts peut déléguer son
pouvoir.