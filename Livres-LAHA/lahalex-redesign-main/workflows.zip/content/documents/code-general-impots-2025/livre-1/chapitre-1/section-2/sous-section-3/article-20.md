Article 20 :
1) Le bénéfice est établi sous déduction de toutes charges remplissant les conditions suivantes :
1) être comprises dans les charges de l’exercice au cours duquel elles ont été
engagées ;
2) être exposées dans l’intérêt direct de l’exploitation ou se rattacher à la
gestion normale de l’entreprise ;
3) correspondre à une charge effective ;
3) être  appuyées  des  justifications  suffisantes,  notamment  de  factures
normalisées, sous réserve des dérogations expresses accordées pour certaines activités par le directeur général des impôts ;
5) concourir à la formation d’un produit non exonéré ;
5) se traduire par une diminution de l’actif net de l’entreprise ;
5) pour les sommes donnant lieu à une retenue à la source, apporter la preuve
du paiement de la retenue correspondante.
2) Les charges doivent être comptabilisées dans le respect des principes édictés par
le système comptable de l’Organisation pour l’harmonisation en Afrique du droit des affaires, sous réserve que ceux-ci ne soient pas incompatibles avec les règles applicables pour l’assiette de l’impôt.
3) Outre les conditions générales de déductibilité mentionnées ci-dessus, les charges
décrites aux articles suivants sont soumises à des conditions spécifiques de déductibilité.