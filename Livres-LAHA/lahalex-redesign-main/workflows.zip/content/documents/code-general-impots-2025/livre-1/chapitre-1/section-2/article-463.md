Article 463 :
1) Les personnes assujetties à l’impôt sur les sociétés, à l’impôt sur les bénéfices d’affaires ou à la taxe professionnelle synthétique sont astreintes à la pose d’une enseigne ou d’une plaque signalétique professionnelle sur leurs lieux d’exercice d’activité, notamment les locaux abritant leurs sièges, bureaux, ateliers et/ou usines, magasins de dépôt ou de ventes.
2) L’enseigne ou la plaque signalétique professionnelle doit, tout en respectant les
règles d’exercice de la profession, comporter au moins les renseignements ci-après :
1) la dénomination ou la raison sociale ;
1) l’adresse  complète  précisant  obligatoirement  le  numéro  «  rue  entrée
parcelle » du lieu d’exercice de l’activité et le numéro de téléphone fonctionnel ;
3) le numéro d’immatriculation au registre de commerce et de crédit mobilier
ou le numéro d’identification professionnelle ;
4) le numéro d’identifiant fiscal unique.
3) L’enseigne ou la plaque signalétique professionnelle doit être fixée de manière
visible et lisible au-dessus de l’entrée principale de l’emplacement indiqué au paragraphe 1 du présent article.