Article 51 :
1) L’impôt sur les sociétés doit être payé en quatre (4) termes déterminés provisoirement d’après l’impôt de l’année précédente.
Les paiements doivent être effectués au plus tard le 10 des mois de mars, juin, septembre, décembre de chaque année.
2) Le  montant  de  chaque  acompte  est  égal  au  quart  de  l’impôt  dû  l’année
précédente.
Toutefois, s’agissant du premier acompte payable au plus tard le 10 mars, au cas où la déclaration de l’exercice précédent n’est pas encore déposée, il est provisoirement calculé sur la base de l’impôt (dû ou acquitté) au titre de l’avant-dernier exercice. Le montant de cet acompte doit, lors du versement du deuxième acompte, faire l’objet d’une régularisation sur la base du dernier exercice.
3) Le solde de l’impôt dû est acquitté le jour du dépôt de la déclaration annuelle.
Si les acomptes ou versements sont supérieurs aux impositions établies, la différence est considérée comme un crédit d’impôt imputable sur les échéances ultérieures de l’impôt sur les sociétés et les arriérés d’impôt s’il en existe.