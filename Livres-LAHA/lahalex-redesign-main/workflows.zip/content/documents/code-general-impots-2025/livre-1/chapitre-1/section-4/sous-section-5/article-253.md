Article 253 :
Peuvent obtenir, sur leur demande, remboursement des crédits de taxe sur la valeur ajoutée dont ils disposent à l’issue d’un bimestre civil :
1) les producteurs ;
1) les assujettis qui réalisent, pour plus de la moitié de leur chiffre d’affaires annuel, des
opérations d’exportation ou des opérations assimilées ;
3) les assujettis qui acquièrent des biens d’investissement ouvrant droit à déduction
pour une valeur supérieure à quarante millions (40 000 000) de francs CFA toutes taxes comprises ;
4) les assujettis qui cessent définitivement leur activité.