Article 278 :
Le montant de la taxe spécifique appliqué aux tabacs et cigarettes, est affecté à raison de :
80% pour le trésor public ; 20% pour la promotion du sport.