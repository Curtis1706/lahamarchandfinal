Article 259 :
1) Tout assujetti à la taxe sur la valeur ajoutée est tenu de souscrire, auprès du service des impôts au plus tard le 10 de chaque mois, et au titre du mois précédent, une déclaration conforme au modèle prescrit, indiquant :
1) les montants de ses opérations taxables et non taxables ;
1) le montant brut de la taxe liquidée ;
1) le détail des déductions opérées ;
1) le montant de la taxe exigible ou, le cas échéant, le crédit de la taxe.
2) Le retard de dépôt de la déclaration mensuelle et de versement de l’impôt
correspondant est sanctionné par une pénalité établie conformément aux dispositions des articles 485 et 487 du présent code.
3) La taxe exigible est payée directement et spontanément à l’appui de cette
déclaration.