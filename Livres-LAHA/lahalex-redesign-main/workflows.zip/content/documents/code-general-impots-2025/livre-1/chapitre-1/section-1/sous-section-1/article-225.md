Article 225 :
1) Peuvent être soumises à la taxe sur la valeur ajoutée sur option du redevable :
1) les opérations de transport public de voyageurs ;
1) l’importation, la production et la revente des produits exonérés énumérés au