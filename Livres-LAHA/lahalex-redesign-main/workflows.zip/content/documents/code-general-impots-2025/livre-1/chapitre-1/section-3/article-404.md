Article 404 :
Sont solidaires pour le paiement des droits de timbre et des amendes :
1) tous les signataires, pour les actes synallagmatiques ;
1) les prêteurs et les emprunteurs, pour les obligations ;
1) les officiers ministériels qui ont reçu ou rédigé des actes énonçant des actes ou
livres non timbrés.