Article 178 :
Les contribuables relevant de l’impôt sur les bénéfices d’affaires mais dont le chiffre d’affaires est inférieur ou égal à un seuil fixé par arrêté du ministre en charge des finances, sont, quelle que soit la nature de leur activité, soumis à une contribution unique dénommée taxe professionnelle synthétique libératoire des impôts et taxes ci- après :
1) l’impôt sur les bénéfices d’affaires ;
1) la contribution des patentes ;
1) la contribution des licences ;
1) le versement patronal sur les salaires.

