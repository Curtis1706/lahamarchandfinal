Article 236 :
1) L’exigibilité de la taxe sur la valeur ajoutée intervient :
1) pour les importations, au moment de l’enregistrement de la déclaration de
mise à la consommation des biens ;
2) pour les prestations de service, les travaux immobiliers et les marchés publics
de l’État, des collectivités locales et des sociétés, établissements et offices de l’État, à l’encaissement du prix, des acomptes ou avances ;
3) dans tous les autres cas, lors de la réalisation du fait générateur ;
2)  Pour  les  opérations  autres  que  les  importations,  le  versement  d’avances  ou acomptes  rend  la  taxe  exigible  sur  le  montant  dudit  versement,  que  l’opération  soit matériellement réalisée ou non.