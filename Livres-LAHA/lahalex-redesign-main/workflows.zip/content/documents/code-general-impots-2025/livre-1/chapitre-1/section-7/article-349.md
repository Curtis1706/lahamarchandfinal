Article  349 :
1)  Les  ordonnances  de  toute  nature,  les  jugements,  les  sentences arbitrales et les arrêts, y compris les décisions de la Cour suprême, sont passibles, sur le montant des condamnations prononcées, d’un droit de 5%.
2) Toutefois :
1) les jugements ou arrêts rendus en matière sociale assortis de condamnation
sont enregistrés au taux de 4% du montant de la condamnation prononcée ;
2) les jugements ou arrêts de liquidation d’astreinte, quant à eux, sont passibles
d’un droit de 25% du montant à recouvrer.
3) Lorsque le droit proportionnel a été acquitté sur un jugement rendu par défaut, la
perception  sur  le  jugement  contradictoire  qui  peut  intervenir  n’a  lieu  que  sur  le complément des condamnations ; il en est de même pour les jugements et arrêts rendus sur appel.
4) Le droit proportionnel n’est pas exigible sur les jugements, sentences arbitrales et
arrêts qui ordonnent le paiement d’une pension à titre d’aliments.