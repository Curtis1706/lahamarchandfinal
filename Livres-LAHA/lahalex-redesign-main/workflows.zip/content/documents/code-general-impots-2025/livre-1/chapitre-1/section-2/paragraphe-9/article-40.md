Article  40 :
1)  Les  entreprises  peuvent  amortir  suivant  le  système  dégressif  leurs matériels et outillages remplissant les conditions ci-après :
1) être acquis à l’état neuf pour une valeur unitaire au moins égale à dix millions
(10 000 000) de francs CFA hors taxe sur la valeur ajoutée ;
2) être utilisables pendant une durée supérieure à trois (3) ans.
2) Le taux dégressif est obtenu par l’affectation au taux d’amortissement linéaire d’un
coefficient de :
1,5 lorsque la durée normale d’utilisation du bien est de trois (3) ou quatre (4) ans ;
2,0 lorsque cette durée normale est de cinq (5) ou six (6) ans ;
2,5 lorsque cette durée normale est supérieure à six (6) ans.
3) Le montant de la première annuité d’amortissement dégressif est déterminé en appliquant au prix de revient de l’immobilisation, le taux utilisable tel que défini ci-dessus.
Le point de départ du calcul de l’amortissement dégressif est constitué par le premier jour du mois d’acquisition ou de création du bien.
Les annuités suivantes se calculent en appliquant le pourcentage d’amortissement retenu au prix de revient du bien diminué du montant des annuités précédentes.
Lorsque le montant de l’annuité dégressive pour un exercice devient inférieur au rapport de la valeur résiduelle sur le nombre d’années restant à courir, l’entreprise peut alors pratiquer un amortissement égal à ce rapport.
4) Un tableau spécial des immobilisations faisant l’objet d’un amortissement dégressif
est produit lors de la déclaration annuelle des résultats.