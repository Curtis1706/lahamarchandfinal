Article 247 :
Sont exclus du droit à déduction y compris lorsque les biens ou services concernés sont utilisés pour la réalisation d’opérations ouvrant droit à déduction :
1) les acquisitions de véhicules de tourisme ou à usage mixte ainsi que leurs parties,
pièces détachées ou accessoires, à l’exception :
1) des véhicules acquis par les loueurs professionnels ou les crédits-bailleurs ;
1) des véhicules stockés par les concessionnaires et destinés à la vente ;
1) des véhicules affectés à l’enseignement de la conduite.
Cette exclusion s’applique également à la taxe sur la valeur ajoutée grevant le prix de location des mêmes véhicules
2) les frais de carburant pour véhicules, à l'exception de ceux engagés pour les
véhicules affectés exclusivement aux activités de transport public de personnes ou de marchandises assujetties à la taxe sur la valeur ajoutée ;
3) les dépenses engagées pour assurer le logement ou l’hébergement des dirigeants
et du personnel non chargé de la surveillance ou de la sécurité de l’entreprise, ainsi que les dépenses de réception, de restaurant, de spectacles et de déplacement, à l’exclusion des dépenses exposées pour la satisfaction des besoins collectifs du personnel sur le lieu de travail ;
4) les  frais  de  réception,  de  restauration,  de  spectacles,  ou  ceux  à  caractère
somptuaire.  Cette  exclusion  ne  concerne  pas  les  professionnels  du  tourisme,  de  la restauration et du spectacle, dans le cadre de leur activité professionnelle ;
5) le mobilier et le matériel de logement ;
5) les dons et libéralités, y compris ceux ayant un caractère publicitaire, d’une valeur
unitaire hors taxe sur la valeur ajoutée supérieure à dix mille (10 000) francs CFA, ainsi que
les biens dont le prix d’achat est fixé à un niveau très inférieur au prix du marché et dans des conditions telles qu’il traduirait en réalité une libéralité ;
7) les services se rapportant à des biens exclus du droit à déduction.