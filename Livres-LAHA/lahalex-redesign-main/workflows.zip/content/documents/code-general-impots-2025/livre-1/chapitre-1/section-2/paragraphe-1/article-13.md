Article 13 :
1) Les stocks sont évalués conformément aux dispositions de l’article 44 de l’Acte uniforme de l’Organisation pour l’harmonisation en Afrique du droit des affaires relatif au droit comptable et à l’information financière.
Les  matières  premières  et  les  marchandises  payées  d’avance  mais  non réceptionnées, sont comprises dans les stocks.
2) Les travaux en cours sont évalués unité par unité, ou catégorie par catégorie, au
prix de revient, à l’exclusion des frais purement commerciaux et administratifs.
3) Les écarts de conversion des devises ainsi que des créances et dettes libellées en
monnaies étrangères par rapport aux montants initialement comptabilisés sont déterminés à la clôture de chaque exercice en fonction du dernier cours de change et pris en compte pour la détermination du résultat imposable de l’exercice.