Article 26 :
1) Les commissions ou courtages portant sur les marchandises achetées pour  le  compte  d’entreprises  exploitées  en  République  du  Bénin  sont  admises  en déduction du bénéfice imposable dans la limite de 5% du montant des achats hors taxes effectués par les centrales d’achats ou les intermédiaires.
Ces  commissions  doivent  faire  l’objet  d’une  facture  régulière  jointe  à  celle  des fournisseurs.
2) Sont admis en déduction du bénéfice imposable, à condition que la société d’assurance apporte la preuve que les bénéficiaires disposent d’une carte professionnelle valide à la date de l’opération, les commissions ou courtages dus :
1. aux personnes physiques non-salariées mandatées ;
2. aux personnes physiques titulaires d’un mandat d’agent général d’assurance ;
3. aux personnes physiques chargées à titre provisoire pour une période de deux (02) ans au plus non renouvelable des fonctions d’agent général d’assurance ;
4. aux banques, aux établissements financiers, aux institutions de micro finance
agréées, aux caisses d’épargne et à la poste.