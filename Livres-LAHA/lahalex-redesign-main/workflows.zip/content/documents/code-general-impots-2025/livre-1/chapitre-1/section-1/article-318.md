Article 318 :
Sont obligatoirement soumis à la formalité de l’enregistrement, sauf s’ils en sont exemptés par une disposition législative :
1) les mutations de propriété d’immeubles ou de droits réels immobiliers ;
1) les ventes publiques de meubles ;
1) les cessions de droit au bail, de fonds de commerce ou de clientèle ;
1) les  cessions  d’actions,  de  parts  sociales,  d’obligations  ou  de  créances
négociables ;
5) les actes de sociétés limitativement visés par le présent titre ;
5) les partages de sociétés, d’indivisions ou de communautés ;
5) les baux portant sur des biens meubles ou immeubles, le crédit-bail immobilier ;
5) les marchés et commandes publics portant sur la fourniture de biens, de travaux
ou de services et les contrats de sous-traitance de ces marchés ;
9) les rentes ;
9) les mutations à titre gratuit ;
9) les actes judiciaires ;
9) les actes visés aux articles 353 et 354 du présent code.
Les actes autres que ceux énumérés ci-dessus peuvent être présentés volontairement à la formalité de l’enregistrement par toute partie intéressée.