Article 348 :
Sont enregistrés au droit fixe de dix mille (10 000) francs CFA :
1) les actes de dissolution de sociétés qui ne portent aucune transmission de biens
meubles ou immeubles entre les associés ou autres personnes ;
2) les actes de prorogation des sociétés ainsi que les actes de fusion, scission et
apports partiels d’actifs quels que soient la nature des apports et le mode de fusion ;
3) les actes portant augmentation de capital ;
3) les actes portant cession d’actions ou de parts sociales.