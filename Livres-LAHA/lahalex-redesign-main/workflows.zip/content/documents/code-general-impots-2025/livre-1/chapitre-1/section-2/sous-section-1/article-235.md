Article 235 :
1) Le fait générateur de la taxe sur la valeur ajoutée est constitué :
1) pour les importations, par la mise à la consommation au sens douanier du
terme ;
2) pour les prestations de services, par l’accomplissement des services ;
2) pour les travaux immobiliers, par l’exécution des travaux ;
4) pour les ventes, les échanges et les travaux à façon, par la livraison des biens ;
4) pour les livraisons à soi-même, par la première utilisation du bien ou service.
2) La constatation du fait générateur ne peut en aucun cas être postérieure à
l’établissement d’une facture totale ou partielle.