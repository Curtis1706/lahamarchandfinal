Article 45 :
1) Pour l’établissement de l’impôt sur le revenu ou de l’impôt sur les sociétés dû  par  les  entreprises  qui  sont  sous  la  dépendance  ou  qui  possèdent  le  contrôle d’entreprises situées hors de la République du Bénin au sens du paragraphe 2 du présent article,  les  bénéfices  indirectement  transférés  à  ces  dernières,  soit  par  majoration  ou diminution des prix d’achat ou de vente, soit par tout autre moyen, sont incorporés aux résultats accusés par les comptabilités.
Les bénéfices indirectement transférés sont déterminés par comparaison avec ceux qui auraient été réalisés en l’absence de lien de dépendance ou de contrôle.
2) Des  liens  de  dépendance  ou  de  contrôle  sont  réputés  exister  entre  deux
entreprises :
1) lorsque l’une détient, directement ou par personne interposée, la majorité du
capital social ou des droits de vote de l’autre ou y exerce en fait le pouvoir de décision ou ;
2) lorsqu’elles sont placées l’une et l’autre, dans les conditions définies au point
a, sous le contrôle d’une même entreprise ou d’une même personne.
3) La condition de dépendance ou de contrôle mentionnée au paragraphe 1 du
présent article n’est pas exigée lorsque le transfert s’effectue avec des entreprises établies dans un État étranger ou dans un territoire situé hors de la République du Bénin dont le régime fiscal est privilégié, au sens de l’article 30 du présent code.