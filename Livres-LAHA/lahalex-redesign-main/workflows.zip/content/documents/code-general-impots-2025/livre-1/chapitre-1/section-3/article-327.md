Article 327 :
Sont enregistrés gratis, les actes dont les droits sont à la charge :
1) de l’État, des collectivités locales, des établissements publics ;
1) de la caisse nationale de sécurité sociale ;
1) des associations constituées sous le régime de la loi du 1er juillet 1901 dont la
donation originaire ou, à défaut, les recettes annuelles sont constituées à raison de 80% au moins des fonds publics ;
4) des personnes bénéficiant de l’aide juridictionnelle dans les conditions prévues par
la législation en vigueur.