Article 156 :
1) La taxe foncière unique est due pour l’année entière par le propriétaire au 1er janvier de l’année de l’imposition.
2) Toutefois, la taxe est due :
1) en cas d’usufruit, par l’usufruitier ;
1) en cas de bail emphytéotique, par le preneur ou l’emphytéote ;
1) en cas de bail à construction :
- par le propriétaire, jusqu’à l’année de l’achèvement de la construction ;
- par le locataire, à compter de l’année qui suit celle de l’achèvement. Dans ces cas, le nom du propriétaire doit figurer sur le titre de perception à la suite de celui du redevable.
3) En cas d’impossibilité d’accéder au propriétaire, le possesseur, le mandataire, le
locataire, le légataire ou tout autre ayant droit est tenu d’acquitter ladite taxe au nom et pour le compte du propriétaire.