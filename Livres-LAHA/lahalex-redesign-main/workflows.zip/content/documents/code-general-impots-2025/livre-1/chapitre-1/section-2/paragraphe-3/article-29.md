Article 29 :
Ne sont pas déductibles :
1) les sommes, autres que les remboursements de frais réellement encourus, versées
par un établissement stable à son siège ou à l’un quelconque de ses autres établissements en contrepartie d’une location mobilière ou immobilière, de l’usage de droits de propriété intellectuelle, ou comme commission, pour des services précis fournis ou pour une activité de direction ;
2) les intérêts versés par un établissement stable autre qu’une banque à son siège en
contrepartie des sommes que le siège a prélevées sur ses fonds propres et mises sous quelque forme que ce soit à la disposition de cet établissement stable.