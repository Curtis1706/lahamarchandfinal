Article 461 :
(Modifié par la loi de finances pour 2024) 1) Les opérations ci-après ne peuvent être effectuées que sous réserve de présentation d’un numéro d’identifiant fiscal unique :
1) l’ouverture  d’un  compte  auprès  des  établissements  de  crédit  et  de
microfinance. Sont assimilées à un compte au sens du présent article, les cartes de débit prépayées rechargeables ;
2) la souscription de tout type de contrat d’assurance ;
2) les contrats de branchement ou d’abonnement aux réseaux d’eau et/ou
d’électricité ;
4) l’immatriculation foncière ;
4) l’agrément à une profession réglementée.
Les personnes physiques ou morales offrant les services ci-dessus mentionnés sont tenues d’exiger de leurs clients ou usagers le numéro d’identifiant fiscal unique avant toute opération avec ces derniers. Pour les comptes bancaires ouverts au profit des mineurs ainsi  que  les  contrats  d’assurances  souscrits  pour  ces  derniers,  il  est  exigé  le  numéro d’identifiant fiscal unique du signataire du compte ou du souscripteur.
2) Nul ne peut exercer la profession d’importateur ou d’exportateur ou obtenir de
licence ou d’autorisation d’importation ou d’exportation s’il n’est immatriculé à l’identifiant fiscal  unique,  à  jour  de  ses  obligations  déclaratives,  de  paiement  et  de  tenue  de comptabilité.
Le numéro d’identifiant fiscal unique et la carte d’importateur sont personnels et ne doivent être utilisés que pour l’enlèvement de ses propres marchandises et autres biens. En cas d’usage frauduleux du numéro d’identifiant fiscal unique ou de la carte d’importateur d’autrui pour l’importation de marchandises, le commissionnaire agréé en douane est solidairement responsable du paiement des impositions subséquentes, sans préjudice des sanctions prévues à l’article 495 paragraphe 3 du présent Code et des poursuites pénales à l’encontre des auteurs.
3) Il est fait obligation à toutes personne physique ou morale qui réalise des opérations
d’importation, de transit ou d’exportation de biens et de marchandises sous forme de « groupage » pour le compte d’autrui, de détenir et de communiquer aux agents de l’administration des douanes, la liste nominative, les adresse et numéro d’identification fiscale des importateurs et expéditeurs effectifs de ces biens, leurs quantités et leurs valeurs, sous peine des sanctions prévues à l’article 495 paragraphe 3 du présent Code.
Ces  informations  sont  communiquées  par  la  direction  générale  des  douanes  à l’administration fiscale.