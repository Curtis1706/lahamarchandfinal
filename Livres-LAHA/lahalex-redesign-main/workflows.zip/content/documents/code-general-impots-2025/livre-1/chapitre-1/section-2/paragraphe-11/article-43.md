Article 43 :
1) Le déficit constaté au cours d’un exercice est considéré comme une charge déductible du bénéfice imposable de l’exercice suivant.
2) Si ce bénéfice n’est pas suffisant pour que la déduction puisse être intégralement
opérée, l’excédent du déficit est reporté successivement sur les exercices suivants jusqu’au cinquième exercice qui suit l’exercice déficitaire.
3) Pour être reportable, le déficit constaté au cours d’un exercice :
1) doit être justifié ;
1) ne doit pas avoir déjà été imputé sur le plan fiscal ;
1) doit être à la charge de la société et suppose une identité d’entreprise.
4) Les déficits constatés au titre d’une année au cours de laquelle une société est
exonérée de l’impôt sur les sociétés ne peuvent pas être reportés.
Cette disposition n’est toutefois pas applicable au déficit engendré par l’exonération prévue à l’article 15 du présent code en ce qui concerne les produits des titres émis par la République du Bénin, les collectivités publiques béninoises et leurs démembrements.
5) L’entreprise perd son droit de report déficitaire lorsqu’elle s’abstient de reporter son
déficit sur le premier résultat bénéficiaire suivant, alors même que son bénéfice n’est pas totalement absorbé par les déficits les plus anciens.
6) Les amortissements différés en période fiscalement déficitaire sont assimilés à des
déficits ordinaires.