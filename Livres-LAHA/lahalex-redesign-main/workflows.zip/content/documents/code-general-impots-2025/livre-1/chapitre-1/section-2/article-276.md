Article 276 :
1) La base d’imposition de la taxe est constituée :
1) à l’importation, par la valeur en douane majorée des droits et taxes perçus
à l’entrée, à l’exception de la taxe sur la valeur ajoutée ;
2) en régime intérieur, par le prix de vente sortie-usine, à l’exclusion de la taxe
sur la valeur ajoutée.
2) Sont exclues de la base d’imposition, les sommes perçues par l’assujetti à titre de
consignation lors de la livraison d’emballages récupérables et réutilisables.
3) Lorsqu’une entreprise vendeuse et une entreprise acheteuse sont, quelle que soit
leur forme juridique, dans la dépendance l’une de l’autre, la taxe spéciale ad valorem due par la première doit être assise non sur la valeur des livraisons qu’elle effectue à la seconde, mais sur le prix de vente pratiqué par cette dernière.