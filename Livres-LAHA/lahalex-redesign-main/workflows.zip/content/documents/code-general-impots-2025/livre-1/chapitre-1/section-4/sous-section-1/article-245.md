Article 245 :
1) Le droit à déduction de la taxe sur la valeur ajoutée prend naissance lorsque la taxe déductible devient exigible chez le fournisseur des biens et services.
Pour les importations, le droit à déduction prend naissance lors de la mise à la consommation.
2) La taxe sur la valeur ajoutée qui a grevé les éléments du prix d’une opération
imposable au cours d’un (1) mois donné est déductible au titre de ce mois.
Les déductions qui n’ont pas été prises en compte au titre de la période définie ci- dessus peuvent être mentionnées sur les déclarations déposées au plus tard le 30 avril de l’année suivant celle de l’omission.
Cependant, le redevable a l’obligation de payer par chèque, carte bancaire ou virement bancaire, les achats de marchandises ou de prestations de services supérieurs ou égaux à cent mille (100 000) francs CFA hors taxe sur la valeur ajoutée, sous peine des sanctions prévues à l’article 503 du présent code.