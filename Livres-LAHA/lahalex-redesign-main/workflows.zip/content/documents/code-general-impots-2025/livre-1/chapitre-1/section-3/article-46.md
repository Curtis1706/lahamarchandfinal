Article 46 :
1) Le taux de l’impôt est fixé à :
1) 25 % du bénéfice imposable pour :
- les  personnes  morales  ayant  une  activité  industrielle,  à  l’exception  des
industries extractives ;
- les  écoles  privées  d’enseignement  scolaire,  universitaire,  technique  et
professionnel ;
2) 30% du bénéfice imposable pour les personnes morales autres que celles
énumérées ci-dessus.
2) Pour les sociétés bénéficiant d’une convention minière ou pétrolière, le taux de l’impôt est déterminé par cette convention. Ce taux ne peut toutefois pas être inférieur au taux de droit commun prévu au paragraphe précédent.