Article 240 :
Sont exclus de la base d’imposition :
1) les escomptes de caisse, remises, rabais et ristournes et autres réductions de prix
consenties à condition qu’ils bénéficient effectivement et pour leur montant exact au client et qu’ils figurent sur facture initiale ou facture rectificative et ne constituent pas la rétribution d’une prestation quelconque ;
2) les débours qui ne sont que des remboursements de frais et qui sont refacturés pour
leur montant exact au client ;
3) les sommes perçues à titre de consignation lors de la livraison d’emballages
récupérables et réutilisables à la condition  que les sommes engagées au titre de la consignation soient individualisées sur la facture. Lorsque ces emballages n’ont pas été rendus au terme des délais en usage dans la profession, la taxe sur la valeur ajoutée est due sur le prix de cession.