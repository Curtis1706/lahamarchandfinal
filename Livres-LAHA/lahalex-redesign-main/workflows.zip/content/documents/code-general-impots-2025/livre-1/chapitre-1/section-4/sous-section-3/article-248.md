Article 248 :
Les assujettis qui ne réalisent pas exclusivement des opérations ouvrant droit à déduction doivent, dès la réalisation de leurs dépenses, les affecter soit à leurs activités imposables, soit à leurs activités non imposables :
1) lorsque les biens et services concourent exclusivement à la réalisation d’opérations
ouvrant droit à déduction, la taxe sur la valeur ajoutée qui les a grevées est déductible ;
2) lorsque les biens et services concourent exclusivement à la réalisation d’opérations
n’ouvrant pas droit à déduction, la taxe sur la valeur ajoutée qui les a grevées n’est pas déductible ;
3) lorsque les biens et services concourent à la fois à la réalisation d’opérations
ouvrant droit à déduction et à la réalisation d’opérations n’ouvrant pas droit à déduction, seule une fraction de la taxe qui les a grevées est déductible par application d’un prorata.