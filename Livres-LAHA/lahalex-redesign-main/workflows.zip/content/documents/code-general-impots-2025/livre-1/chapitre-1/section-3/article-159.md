Article 159 :
(Modifié par les lois de finances pour 2023 et 2024) 1) Les taux de la taxe foncière unique sont fixés chaque année par les conseils municipaux ou communaux et ne peuvent excéder les limites ci-après :
- 3 à 7 % pour les propriétés non bâties ;
- 4 à 8 % pour les propriétés bâties.
2) Les collectivités locales doivent faire connaître à la direction générale des impôts
au plus tard le 30 novembre de chaque année, les décisions relatives aux taux d’imposition applicables au 1er janvier de l’année suivante dans leur ressort territorial. À défaut, les impositions sont établies selon les taux de l’année précédente.
Pour les collectivités territoriales n’ayant adopté aucun taux à la date d’entrée en vigueur du présent Code, les taux d’imposition à la taxe foncière unique sont fixés comme suit :
- 5 % pour les propriétés non bâties ;
- 6 % pour les propriétés bâties.
3) Supprimé