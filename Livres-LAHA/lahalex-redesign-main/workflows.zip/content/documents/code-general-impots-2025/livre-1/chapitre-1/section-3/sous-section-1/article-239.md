Article 239 :
Sont inclus dans la base d’imposition :
1) les frais accessoires aux livraisons de biens et services facturés aux clients ;
1) les impôts, droits et taxes, y compris les droits d’accises, à l’exclusion de la taxe sur
la valeur ajoutée ;
3) les compléments de prix acquittés à des titres divers par l’acquéreur des biens ou
le client ;
4) les  sommes  perçues  par  l’assujetti  à  titre  de  consignation  lors  de  la  livraison
d’emballages.