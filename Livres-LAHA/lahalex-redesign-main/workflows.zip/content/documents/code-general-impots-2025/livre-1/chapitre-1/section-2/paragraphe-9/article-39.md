Article 39 :
1) Peuvent faire l’objet d’un amortissement accéléré, les matériels et outillages neufs remplissant la double condition :
1) d’être utilisés exclusivement pour les opérations industrielles de fabrication,
de manutention, d’hôtellerie, de téléphonie, de transport ou d’exploitation agricole ;
2) d’avoir une durée de vie supérieure à cinq (5) ans.
2)  Pour  ces  matériels  et  outillages,  le  montant  de  la  première  annuité d’amortissement, calculé d’après leur durée d’utilisation normale, est doublé, cette durée étant alors réduite d’une année.