Article  32 :
(Modifié  par  la  loi  de  finances  pour  2023)
1)  Les  dons,  cotisations, subventions et autres libéralités sont déductibles dans la limite de un pour mille (1‰) du chiffre d’affaires hors taxes. Ce plafond ne concerne pas les cotisations professionnelles que les entités versent aux organismes de représentation ou de défense des intérêts corporatistes, dans la limite d’une seule cotisation.
2) Les dons et libéralités dans les domaines de l’éducation, de la santé, de l’industrie
culturelle, touristique et des arts ou des infrastructures collectives consentis à l’État, à ses démembrements  et  aux  fédérations  sportives  reconnues  par  le  gouvernement,  sont déductibles dans la limite de vingt-cinq millions (25.000.000) de francs CFA en sus de la déduction accordée au paragraphe précédent. La preuve de la réception des dons et libéralités par le bénéficiaire est jointe obligatoirement à la déclaration de résultat.
3) Les cadeaux et objets spécialement conçus pour la publicité, justifiés par des
factures sont admis en déduction dans la limite de trois pour mille (3 ‰) du montant du chiffre d’affaires hors taxes.
DEPENSES SOMPTUAIRES