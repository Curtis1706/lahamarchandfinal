Article 244 :
1) Pour être déductible, la taxe sur la valeur ajoutée doit figurer :
1) en cas d’importation, sur la déclaration de mise à la consommation assortie
d’un justificatif de paiement émis par l’administration perceptrice dûment habilitée ;
2) en  cas  de  livraison  à  soi-même,  sur  les  déclarations  souscrites  par  le
redevable ;
3) en cas de retenue de la taxe sur la valeur ajoutée à la source, sur une
quittance justificative de la retenue à la source délivrée par le client ;
4) dans tous les autres cas, sur une facture normalisée.
2) Les biens ou services pour lesquels la déduction est demandée :
1) doivent être nécessaires à l’exploitation et utilisés exclusivement pour ses
besoins ;
2) doivent être inscrits en comptabilité ;
2) ne doivent pas faire l’objet d’une exclusion expressément prévue par la loi.
3) La taxe sur la valeur ajoutée dont la déduction est demandée doit être facturée
par un assujetti redevable. La liste des assujettis redevables est publiée périodiquement par la  direction  générale  des  impôts  et  un  certificat  d’assujettissement  est  délivré  à  tout redevable qui en fait la demande.