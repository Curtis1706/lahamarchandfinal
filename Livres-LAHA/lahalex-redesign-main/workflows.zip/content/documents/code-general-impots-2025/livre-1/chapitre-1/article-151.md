Article 151 :
La taxe foncière unique est une contribution annuelle sur les propriétés foncières sises en République du Bénin.