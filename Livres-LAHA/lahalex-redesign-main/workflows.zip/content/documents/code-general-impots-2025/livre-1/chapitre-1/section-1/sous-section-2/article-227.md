Article 227 :
Pour se prévaloir de la qualité d’assujetti, tout redevable doit :
1) s’enregistrer auprès de l’administration fiscale et obtenir un identifiant fiscal unique
dans les conditions prévues par l’article 460 du présent code ;
2) tenir une comptabilité conforme au système normal du système comptable de
l’Organisation pour l’harmonisation en Afrique du droit des affaires.