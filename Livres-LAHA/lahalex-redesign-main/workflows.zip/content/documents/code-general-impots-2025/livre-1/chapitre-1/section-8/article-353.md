Article 353 :
Sont enregistrés au droit fixe de deux mille cinq cent (2.500) francs CFA :
1) Les actes non soumis à l’enregistrement en vertu du présent code mais qui sont
présentés volontairement à la formalité par les parties.
2) Les certificats de propriété.
2) Les  acceptations  et  renonciations  pures  et  simples  de  succession,  legs  ou
communautés.
4) Tous actes et contrats exclusivement relatifs à la concession par l’auteur ou des
représentants du droit de reproduire ou d’exécuter une œuvre littéraire ou artistique.
5) Les inventaires de meubles, objets mobiliers, titres et papiers, ainsi que les clôtures
d’inventaire. Il est dû un droit pour chaque vacation.
6) Les actes des huissiers et autres ayant pouvoir de faire des exploits et procès-
verbaux, qui ne contiennent aucune disposition pouvant donner lieu au droit proportionnel.
7) Les prisées de meubles.
7) Les testaments et tous autres actes de libéralités qui ne contiennent que des
dispositions soumises à l’avènement du décès du disposant.