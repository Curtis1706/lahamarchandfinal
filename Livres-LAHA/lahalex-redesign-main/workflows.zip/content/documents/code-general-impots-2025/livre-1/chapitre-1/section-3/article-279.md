Article 279 :
La taxe est perçue au cordon douanier par la direction générale des douanes pour le compte de la direction générale des impôts.
À l’intérieur, la taxe est collectée et reversée par le producteur.