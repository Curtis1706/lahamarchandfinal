Article 584 :
1) Les réclamations ne sont pas suspensives du paiement des impositions et pénalités y afférentes.
Toutefois, le contribuable peut, s’il en a expressément formulé la demande dans sa réclamation,  surseoir  au  paiement  de  la  partie  contestée  de  ces  impositions  et  des pénalités y afférentes, à condition :
1) de préciser le montant ou les bases du dégrèvement qu’il sollicite ;
1) d’avoir acquitté l’intégralité des impositions non contestées ; et
1) de justifier d’un cautionnement de 25% de la partie contestée au moyen d’un
paiement au trésor public.
2)  A  défaut  de  constitution  du  cautionnement  visé  à  l’alinéa  précédent,  le recouvrement de la partie contestée de l’impôt est poursuivi par toutes voies de droit à l’exclusion de la vente forcée qui ne peut intervenir qu’après la notification de la décision de rejet de la réclamation par le ministre chargé des finances.