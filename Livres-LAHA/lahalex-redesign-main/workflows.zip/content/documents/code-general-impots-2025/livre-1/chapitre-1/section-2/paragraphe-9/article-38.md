Article 38 :
1) Sont déductibles, les amortissements réellement comptabilisés dans la limite  de  ceux  qui  sont  généralement  admis  d’après  les  usages  de  chaque  nature d’industrie, de commerce ou d’exploitation.
Les taux d’amortissements généralement admis par l’administration sont fixés par arrêté du ministre chargé des finances.
2) La valeur d’entrée des biens est le coût d’acquisition déterminé conformément
aux règles comptables. Toutefois, les charges non encore réelles, estimées, sont exclues de la base amortissable.
29
Ces charges non réelles, estimées à l’acquisition du bien, sont déductibles pour leur montant réel, à partir de l’exercice au cours duquel elles sont engagées. Cette déduction de charges est étalée de façon linéaire sur cinq (5) exercices consécutifs.
3) Les brevets, licences et autres droits immatériels d’une valeur inférieure à un million
(1 000 000) de francs CFA et les petits outillages d’une valeur unitaire inférieure à deux cent cinquante mille (250 000) francs CFA peuvent être entièrement amortis dès leur acquisition, s’ils sont portés en frais généraux et non à un poste d’actif immobilisé.
4) L’amortissement des voitures de tourisme n’est déductible que pour la fraction de
leur  prix  d’acquisition  toutes  taxes  comprises  qui  ne  dépasse  pas  vingt-cinq  millions (25 000 000) de francs CFA. Cette limite s’applique à l’ensemble des véhicules immatriculés dans  la  catégorie  des  voitures  particulières  lorsque  l’exploitation  desdits  véhicules  ne constitue pas l’objet principal du commerce ou de l’industrie.
La limite fixée ci-dessus s’applique également à la part du loyer supportée par le locataire et correspondant à l'amortissement pratiqué par le bailleur pour la fraction du prix d'acquisition.
5) En  matière  de  crédit-bail,  le  crédit-preneur  n’est  autorisé  à  déduire  que  les
amortissements relatifs à l’immobilisation objet du contrat, ainsi que les charges financières liées.