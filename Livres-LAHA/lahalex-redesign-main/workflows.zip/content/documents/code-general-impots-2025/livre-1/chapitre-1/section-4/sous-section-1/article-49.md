Article 49 :
1) Les contribuables soumis à l’impôt sur les sociétés doivent souscrire au plus tard le 30 avril de chaque année, une déclaration de leur résultat de l’exercice précédent.
Les  entreprises  bénéficiaires  d’un  régime  dérogatoire  sont  soumises  aux  mêmes obligations.
2) Cette déclaration doit être remise à l’inspecteur des impôts du lieu du siège social
ou du principal établissement du redevable en République du Bénin.