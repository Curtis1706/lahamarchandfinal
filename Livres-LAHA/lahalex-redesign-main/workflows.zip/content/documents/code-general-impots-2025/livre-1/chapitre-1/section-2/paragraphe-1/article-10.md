Article 10 : Les produits imposables comprennent notamment :
1) les ventes de biens et services ;
2) les produits financiers ;
3) les  produits  hors  activités  ordinaires,  notamment  les  produits  des  cessions
d’éléments de l’actif immobilisé ;
4) les revenus ou produits accessoires ;
5) les produits des valeurs mobilières ;
6) les produits de consignations d’emballages ;
7) les produits de la location des immeubles bâtis et non bâtis, y compris les revenus accessoires ;
8) les aides à caractère commercial ;
9) les travaux en cours ;
10) les reprises et les transferts de charges ;
11) les  dégrèvements  obtenus  de  l’administration  fiscale  au  titre  des  impôts
déductibles ;
12) les gains de change ;
13) les plus-values de réévaluation ou
14) tous autres produits relevant des activités réalisées par les sociétés.