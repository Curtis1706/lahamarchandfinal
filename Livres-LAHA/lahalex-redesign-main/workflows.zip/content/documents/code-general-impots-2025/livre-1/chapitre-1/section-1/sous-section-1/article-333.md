Article 333 :
La mutation d’un immeuble est suffisamment établie pour la demande des droits d’enregistrement et la poursuite du paiement contre le nouveau possesseur :
1) soit par la production d’un titre foncier ;
1) soit par la production d’un titre de jouissance défini par la réglementation foncière ;
1) soit par des baux par lui passés, soit par des transactions ou autres actes constatant
sa propriété ou son usufruit.