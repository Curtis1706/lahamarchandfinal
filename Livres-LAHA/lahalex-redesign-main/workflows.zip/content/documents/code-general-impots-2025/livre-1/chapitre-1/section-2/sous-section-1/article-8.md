Article  8 :
1)  L’impôt  est  établi  chaque  année  sur  les  bénéfices  réalisés  l’année précédente.
2) Les contribuables sont tenus de clôturer chaque année leurs comptes à la date du
31 décembre, sauf en cas de cession ou de cessation d’activités en cours d’année.
Toutefois, les établissements d’enseignement peuvent clôturer leurs comptes au 31 août  de  chaque  année.  Les  conditions  d’application  du  présent  paragraphe  sont précisées par voie réglementaire.
3) Les entreprises créées antérieurement au 1er juillet d’une année, sont tenues de
clôturer leur premier exercice comptable au 31 décembre de la même année.
4) Les entreprises créées postérieurement au 30 juin d’une année, peuvent clôturer
leur premier exercice comptable au 31 décembre de l’année suivante, sur demande adressée à l’inspecteur des impôts au plus tard le 31 janvier suivant la date de création.
La réponse du service doit intervenir dans les quinze (15) jours de la demande ; le défaut de réponse vaut acceptation.
Dans ce cas, l’impôt est établi sur les bénéfices réalisés au cours de la période retenue. Toutefois, l’entreprise acquitte l’impôt minimum de la période allant de la date de création au 31 décembre de la même année. Cet impôt minimum vient ensuite en déduction de l’impôt dû au titre des résultats du bilan dans lequel il est compris.