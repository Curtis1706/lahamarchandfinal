Article 158 :
(Modifié par la loi de finances pour 2025) 1) Les terrains et propriétés non bâties sont imposés sur la base de leur évaluation administrative au 1er janvier de l’année d’imposition.
2) Les évaluations administratives sont déterminées en fonction des valeurs vénales
par les conseils municipaux et sont susceptibles de révision tous les cinq (5) ans.
3) Les collectivités locales doivent faire connaître à la direction générale des impôts
au plus tard le 30 novembre précédant la fin de chaque période quinquennale, les décisions relatives aux valeurs vénales applicables à compter du 1er janvier du quinquennat suivant dans leur ressort territorial. À défaut, les impositions sont établies selon les taux du quinquennat précédent.
Pour les collectivités n’ayant adopté aucune valeur vénale à la date d’entrée en vigueur de la présente disposition, les bases d’imposition sont fixées par arrêté du ministre chargé des Finances.