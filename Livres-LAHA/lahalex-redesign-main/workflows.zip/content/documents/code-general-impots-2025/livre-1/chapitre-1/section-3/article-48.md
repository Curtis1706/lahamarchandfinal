Article 48 :
1) Les sociétés d’assurance de  dommages de toute nature doivent, lorsqu’elles  rapportent  au  résultat  imposable  d’un  exercice  l’excédent  des  provisions constituées pour faire face au règlement des sinistres advenus au cours d’un exercice antérieur, acquitter un complément d’impôt sur les  sociétés, représentatif  de l’intérêt correspondant à l’avantage de trésorerie ainsi obtenu. Ce complément ne s’applique pas aux provisions constituées à raison des opérations de réassurance.
2) Le complément de l’impôt sur les sociétés est égal à 5% des montants réintégrés.
Il est déclaré et payé annuellement en même temps que le solde de l’impôt sur les sociétés de la société d’assurance.
3) Les  modalités  d’application  du  présent  article  seront  précisées  par  voie
réglementaire.