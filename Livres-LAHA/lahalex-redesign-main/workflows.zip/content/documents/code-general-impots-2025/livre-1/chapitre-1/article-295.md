Article 295 :
Les modalités de déclaration, de contrôle et de recouvrement, ainsi que les obligations et sanctions sont celles prévues en matière de taxe sur la valeur ajoutée.