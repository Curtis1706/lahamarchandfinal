Article 23 :
1) Est déductible, l’indemnité de congé payé calculée conformément à la  législation  du  travail,  y  compris  les  charges  sociales  et  fiscales  afférentes  à  cette indemnité.
2)  Sont  également  déductibles,  s’ils  remplissent  les  conditions  générales  de
déductibilité des charges :
1) les frais de formation du personnel ;
1) les indemnités de maladie ;
1) la prime d’assurance maladie versée par l’entreprise à une compagnie
d’assurance  dans  le  cadre  de  l’exécution  d’un  contrat  souscrit  pour  l’ensemble  du personnel ou pour un employé donné.