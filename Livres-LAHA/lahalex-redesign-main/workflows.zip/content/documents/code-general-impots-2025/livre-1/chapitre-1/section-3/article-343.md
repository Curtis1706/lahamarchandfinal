Article 343 :
1) Les partages de biens meubles et immeubles entre copropriétaires, cohéritiers et coassociés, à quelque titre que ce soit, sont soumis à un droit de 0,5%.
Le droit est liquidé sur le montant de l’actif net partagé.
2) En cas de soulte ou de retour de partage, le droit exigible est celui des mutations à
titre onéreux applicable au bien concerné.