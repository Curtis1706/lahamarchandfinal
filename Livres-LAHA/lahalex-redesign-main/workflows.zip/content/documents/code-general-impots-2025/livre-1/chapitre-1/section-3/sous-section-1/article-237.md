Article 237 :
La base d’imposition de la taxe sur la valeur ajoutée est constituée :
1) pour les importations, par la valeur en douane de la marchandise augmentée des
droits et taxes de toute nature, notamment les droits de douane et les droits d’accises, à l’exclusion de la taxe sur la valeur ajoutée elle-même et de la contribution sur la vente de services de communications électroniques ;
2) pour les livraisons de biens vendus et les prestations de service, par tous les sommes,
valeurs, biens ou services reçus ou à recevoir en contrepartie de la livraison ou de la prestation ;
3) pour les travaux immobiliers, par le montant des mémoires, marchés, factures ou
acomptes ;
4) pour les livraisons à eux-mêmes que se font les assujettis, par le prix d’achat de biens
ou de services similaires ou, à défaut, par leur prix de revient ;
5) pour les opérations effectuées par les sociétés d’intérim consistant à recruter de la
main  d’œuvre  pour  le  compte  d’autres  entreprises,  par  la  rémunération  du  service uniquement s’il est facturé séparément du montant du salaire brut ;
6) pour les aides aux entreprises visées au paragraphe 8 de l’article 224 du présent
code, par le montant de la contrepartie entraînant l’imposition à la taxe sur la valeur ajoutée. Si ce montant n’est pas clairement stipulé par l’organisme versant, l’ensemble de l’aide est soumis à la taxe sur la valeur ajoutée.