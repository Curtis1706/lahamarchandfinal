Article 277 :
(Modifié par la loi de finances pour 2025) Le taux de la taxe est fixé comme suit :
1) cigarettes, cigares, cigarillos, tabac à fumer et autres succédanés de tabacs :
40% ;
2) boissons alcoolisées : 15 %
3) boissons non alcoolisées :
1. boissons non alcoolisées énergisantes : 20% ;
1. boissons non alcoolisées à l’exception de l’eau non gazéifiée : 7% ;
1. eau minérale importée : 20% ;
1. jus de fruits importé : 20% ;
3) farine de blé : 1% ;
3) pâtes alimentaires importées : 5% ;
3) huiles et corps gras alimentaires :
1. préparations pour soupe ou bouillons préparés : 10% ;
1. huiles et autres corps gras alimentaires : 1% ;
3) café, thé : 10% ;
3) produits de parfumerie et cosmétiques : 15% ;
3) sachets en matière plastique : 5% ;
3) marbre, lingots d’or et pierres précieuses : 10%.