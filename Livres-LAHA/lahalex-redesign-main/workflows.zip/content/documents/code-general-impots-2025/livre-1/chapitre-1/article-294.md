Article 294 :
1) Les réceptifs hôteliers sont astreints à la tenue des documents ci-après :
1) le registre de police ;
1) la main courante ou le tableau d’occupation ;
1) le brouillard journalier et mensuel de caisse et de banque.
2) Si la gestion des séjours et la tenue de la comptabilité sont informatisées, le
déclarant est tenu de mettre en place des procédures qui permettent de satisfaire aux exigences de régularité, de sauvegarde et de sécurité des données ainsi que leur accès en permanence grâce à un système informatique intégré. Ce dernier est soumis à une procédure d’homologation.
3) Les modalités d’application de l’alinéa précédent sont fixées par arrêté conjoint
des ministres chargés du tourisme et des finances.