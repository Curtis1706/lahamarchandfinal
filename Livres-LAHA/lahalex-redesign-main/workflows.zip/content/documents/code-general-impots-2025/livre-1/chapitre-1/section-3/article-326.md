Article  326 :
La  valeur  de  la  nue-propriété  et  de  l’usufruit  des  biens  meubles  et immeubles est déterminée comme suit :
1) Pour les transmissions à titre onéreux, par le prix exprimé en y ajoutant toutes les
charges en capital.
2) Pour les mutations à titre gratuit, la valeur imposable de la nue-propriété et de
l’usufruit est déterminée conformément au tableau ci-après :
<table><tr><th colspan="1" rowspan="2"><b>Age de l’usufruitier</b> </th><th colspan="2"><b>Valeur par rapport à la pleine propriété :</b> </th></tr>
<tr><td colspan="1"><b>de l’usufruit</b> </td><td colspan="1"><b>de la nue-propriété</b> </td></tr>
<tr><td colspan="1">Moins de 20 ans révolus </td><td colspan="1">7/10e </td><td colspan="1">3/10e </td></tr>
<tr><td colspan="1">Moins de 30 ans révolus </td><td colspan="1">6/10e </td><td colspan="1">4/10e </td></tr>
<tr><td colspan="1">Moins de 40 ans révolus </td><td colspan="1">5/10e </td><td colspan="1">5/10e </td></tr>
<tr><td colspan="1">Moins de 50 ans révolus </td><td colspan="1">4/10e </td><td colspan="1">6/10e </td></tr>
<tr><td colspan="1">Moins de 60 ans révolus </td><td colspan="1">3/10e </td><td colspan="1">7/10e </td></tr>
<tr><td colspan="1">Moins de 70 ans révolus </td><td colspan="1">2/10e </td><td colspan="1">8/10e </td></tr>
<tr><td colspan="1">Plus de 70 ans révolus </td><td colspan="1">1/10e </td><td colspan="1">9/10e </td></tr>
</table>
Pour déterminer la valeur de la nue-propriété, il n’est tenu compte que des usufruits ouverts au jour de la mutation de cette nue-propriété.
Toutefois, dans le cas d’usufruits successifs, l’usufruit éventuel venant à s’ouvrir, le nu- propriétaire aura droit à la restitution d’une somme égale à ce qui aurait été payé en moins, si le droit acquitté par lui avait été calculé d’après l’âge de l’usufruitier éventuel. L’action en restitution ouverte au profit du nu-propriétaire se prescrit par deux (2) ans, à compter du jour du décès du précédent usufruitier.
3) Pour les mutations à titre gratuit, si l’usufruit est constitué pour une durée fixe, il est
estimé aux deux dixièmes (2/10e) de la valeur de la propriété entière pour chaque période de dix (10) ans de la durée de l’usufruit, sans fraction et sans égard à l’âge de l’usufruitier.
4) Il n’est rien dû pour la réunion de l’usufruit à la propriété, lorsque cette réunion a lieu
par le décès de l’usufruitier ou l’expiration du temps fixé pour la durée de l’usufruit.
FIXATION DES DROITS