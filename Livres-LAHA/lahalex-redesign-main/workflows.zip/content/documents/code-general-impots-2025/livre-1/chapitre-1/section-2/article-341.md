Article 341 :
1) Sont assujettis au droit de 1% :
1) les baux d’immeubles à durée déterminée, qu’ils soient à durée fixe ou à
période, ainsi que les sous-baux et prorogations conventionnelles ou légales de baux de même nature ;
2) les baux à construction.
Ce taux s’applique sur le montant cumulé des loyers de toute la période. En cas de renouvellement du bail, notamment par tacite reconduction, un nouveau droit est dû sur la nouvelle période.
Si le bail est stipulé pour une durée supérieure à trois (3) ans, ou pour les baux à période, le droit peut être fractionné conformément aux dispositions de l’article 367 du présent code.
2) Les baux à vie de biens immeubles et ceux dont la durée est illimitée sont assujettis
au droit prévu en matière de mutation immobilière à titre onéreux, applicable :
1) pour les baux à vie, sur un capital formé de dix (10) fois le prix annuel charges
comprises, en y ajoutant les deniers d’entrée et les autres charges ;
2) pour les baux dont la durée est illimitée, sur un capital formé de vingt (20) fois
le prix annuel charges comprises, y compris le droit d’entrée s’il en est stipulé.
3) L’acte constitutif de l’emphytéose est soumis au droit de 1%.
Le droit est liquidé sans fractionnement sur le montant cumulé des redevances pour toute  la  durée  du  bail,  augmenté  des  charges  additionnelles  stipulées  au  bail,  sur déclaration estimative, s’il y a lieu.
4) Le crédit-bail immobilier entraîne également la perception du droit de bail au taux
de 1% payé annuellement sur le montant des loyers stipulés.