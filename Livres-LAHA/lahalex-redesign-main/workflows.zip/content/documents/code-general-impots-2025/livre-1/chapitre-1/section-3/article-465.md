Article 465 :
(Modifié par la loi de finances pour 2024) 1) Les entreprises qui exercent des activités en République du Bénin ou y possèdent des biens sans y avoir leur siège social, et qui y sont imposables à l’impôt sur les sociétés ou à l’impôt sur les bénéfices d’affaires, sont tenues de :
1) désigner un représentant en République du Bénin nanti des pouvoirs en vue
de les représenter valablement ;
2) présenter à toute réquisition de l’administration fiscale les documents dont la
tenue est prescrite par la législation fiscale ;
3) se conformer aux obligations comptables et de dépôt des états financiers,
en indiquant les nom et adresse du ou des comptables ou experts chargés de tenir leur comptabilité.
Le représentant ainsi désigné est tenu à toutes les obligations déclaratives et de paiement des impôts, droits et taxes dus par l’entreprise représentée. À défaut de la désignation  d’un  représentant,  les  membres  établis  en  République  du  Bénin,  des groupements momentanés d’entreprises, ayant en leur sein une ou plusieurs entreprises non-résidentes, sont réputés constituer les représentants de celles-ci.
2)  A  défaut,  ces  entreprises  encourent  la  procédure  de  taxation  d’office  sans
préjudice des sanctions fiscales et pénales prévues au titre 2 du livre 4 du présent code.