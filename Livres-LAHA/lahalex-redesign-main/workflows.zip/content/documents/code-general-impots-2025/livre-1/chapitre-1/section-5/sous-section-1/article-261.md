Article 261 :
Pour les importations :
1) le redevable est tenu de faire apparaître distinctement sur la déclaration de mise
à la consommation, la valeur en douane de la marchandise ou du produit et l’identifiant fiscal unique.
2) la liquidation et le paiement de la taxe sur la valeur ajoutée, la constatation des
infractions, le traitement du contentieux sont soumis aux mêmes règles de procédure qu’en matière de droits de douane.