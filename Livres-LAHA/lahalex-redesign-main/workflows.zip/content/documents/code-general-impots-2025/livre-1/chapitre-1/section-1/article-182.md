Article 182 :
1) En cas de dépassement du seuil prévu à l’article 178 du présent code, le contribuable est tenu de se soumettre aux dispositions relatives au régime de l’impôt sur le bénéfice d’affaires au plus tard le premier jour du mois suivant la constatation du dépassement. Toutefois, lorsque le dépassement du seuil intervient au cours du mois de décembre, le passage au régime supérieur n’intervient qu’au titre de l’année suivante.
107
2) Les dispositions du précédent alinéa s’appliquent également lorsque le montant
des achats de biens et services, équipements et celui des contrats signés dépasse le seuil fixé à l'article 178 du présent code.
3) La taxe professionnelle synthétique payée avant le changement de régime est
considérée comme un acompte imputable sur les nouvelles impositions, à raison de 50% pour les impôts locaux et 50% pour les impôts d’État.
4) En cas de dépassement du seuil d’imposition à la taxe professionnelle synthétique
à l’issue d’un contrôle, le contribuable est reclassé de droit à l’impôt sur les bénéfices d’affaires.
5) Les contribuables relevant de l’impôt sur les bénéfices d’affaires dont le chiffre
d’affaires s’abaisse en-dessous de la limite prévue à l’article 178 du présent code, ne sont soumis au régime de la taxe professionnelle synthétique que lorsque le chiffre d’affaires est resté inférieur à cette limite durant deux (2) exercices consécutifs.