Article 180 :
Sont exonérés de la taxe professionnelle synthétique :
1) les peintres, sculpteurs, graveurs, dessinateurs et autres personnes considérées
comme artistes et ne vendant que le produit de leur art ;
2) les entreprises et sociétés d’exploitation agricole, de pêche et d’élevage ;
2) les entreprises nouvelles régulièrement créées, au titre de leurs douze (12) premiers
mois d’activité. Au titre de l’année d’expiration de la période d’exonération, la taxe est due à partir du premier jour du mois suivant celui au cours duquel le délai est échu.