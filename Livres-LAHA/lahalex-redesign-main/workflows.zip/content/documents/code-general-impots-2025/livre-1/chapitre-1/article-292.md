Article 292 :
Le montant de la taxe est déterminé en fonction des prix pratiqués comme suit :
- tarif inférieur ou égal à 20 000 francs CFA : 500 francs CFA par jour ou par nuit ;
- tarif supérieur à 20 000 et inférieur ou égal à 100 000 : 1.500 francs CFA par jour ou
par nuit ;
- tarif supérieur à 100 000 : 2.500 francs CFA par jour ou par nuit.