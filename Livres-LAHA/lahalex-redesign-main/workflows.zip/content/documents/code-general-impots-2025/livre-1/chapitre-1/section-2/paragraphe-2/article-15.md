Article 15 :
1) Est exonéré, le revenu net des valeurs et capitaux mobiliers figurant à l’actif de l’entreprise et atteint par l’impôt sur le revenu des capitaux mobiliers ou exonéré de cet impôt par les textes en vigueur dans les conditions et sous les réserves ci-après.
2) Au montant de ce revenu est imputée une quote-part des frais et charges fixée
forfaitairement à 30% de ce montant en ce qui concerne les revenus autres que les produits des titres émis par la République du Bénin, les collectivités publiques béninoises et leurs démembrements.
3) Les dispositions du paragraphe 1 ci-dessus s’appliquent également au revenu net
des participations reçu par la holding ou société mère.
4) Sont exclus de l’exonération ci-dessus, les produits des prêts non représentés par
des titres négociables, ainsi que les produits des dépôts et comptes courants, lorsqu’ils sont encaissés par et pour le compte des banquiers ou d’établissements de gestion de valeurs mobilières, ainsi que des sociétés autorisées par le gouvernement à faire des opérations de crédit foncier.