Article 319 :
1) En dehors des cas prévus par la loi, les droits d’enregistrement ne peuvent  faire  l’objet  d’aucune  exemption,  exonération,  modération  ou  suspension  à quelque titre que ce soit.
2) Les actes exonérés de droit d’enregistrement par une disposition législative ou par un accord international restent soumis à la formalité de l’enregistrement et sont enregistrés gratis.
187