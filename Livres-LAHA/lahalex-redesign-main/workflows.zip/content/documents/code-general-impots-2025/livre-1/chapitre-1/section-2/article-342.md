Article 342 :
1) Les baux de biens meubles sont assujettis à un droit :
de 1% s’ils sont faits pour un temps limité ;
de 5% s’ils sont faits pour un temps illimité.
2) Toutefois :
1) les baux de biens meubles soumis à la taxe sur la valeur ajoutée sont exonérés
d’enregistrement. Cette exonération ne s’applique pas aux baux passés par marché public et soumis au droit prévu par l’article 346 du présent code ;
2) les contrats de crédit-bail mobilier ne sont soumis ni au droit de bail, ni au droit
de mutation lors de l’acquisition des biens par le locataire.