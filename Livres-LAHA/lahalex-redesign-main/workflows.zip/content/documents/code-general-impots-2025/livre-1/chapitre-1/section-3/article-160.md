Article 160 :
1) Le produit de la taxe foncière unique est affecté au budget de la commune sur le territoire de laquelle elle est assise, sous déduction de 10% représentant le coût administratif de l’impôt.
Un arrêté du ministre chargé des finances précise les modalités d’application des présentes dispositions.
2) Le représentant de la collectivité bénéficiaire peut demander à l’administration,
communication des bases imposables et proposer la correction des erreurs éventuelles.