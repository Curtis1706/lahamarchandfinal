Article 347 :
Sont enregistrés gratis :
1) Les actes de formation de sociétés et des groupements d’intérêt économique.
Toutefois les apports à titre onéreux d’immeuble, de fonds de commerce ou de droit au bail sont soumis au droit de mutation à titre onéreux applicable au bien apporté.
2) Les actes de prorogation, d’augmentation ou de réduction de capital et de
dissolution des entreprises d’investissement à capital fixe ainsi que les actes constatant les prises de participations effectuées dans le capital d’autres sociétés par les entreprises d’investissement à capital fixe.
3) Les actes de constitution ou d’augmentation de capital des sociétés immobilières
comprenant l’État béninois parmi leurs actionnaires et ayant pour objet d’améliorer les conditions de l’habitat en République du Bénin, soit en facilitant la construction, l’achat ou l’assainissement de maisons d’habitation dites économiques ou à bon marché, soit en construisant elles-mêmes ces habitations en vue de la vente ou de la location ;
4) les actes de location-vente ou de vente d’immeubles bâtis dont le prix n’excède
pas  vingt  millions  (20 000 000)  de  francs  CFA  hors  taxe,  effectués  par  les  personnes physiques  ou  morales  qui  se  consacrent,  avec  l’agrément  et  sous  le  contrôle  de l’administration, au développement de l’habitat économique et social.
La formalité de l’enregistrement des actes énumérés ci-dessus est obligatoire dans le délai d’un (1) mois sous peine des sanctions prévues par l’article 493 du présent code.