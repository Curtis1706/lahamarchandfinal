Article  321 :
Le  fait  générateur  et  l’exigibilité  des  droits  d’enregistrement  sont constitués :
1) pour  les  cessions  et  mutations,  par  le  transfert  de  propriété,  d’usufruit  ou  de
jouissance ;
2) pour les marchés publics et contrats assimilés, par la notification du marché ;
2) dans tous les autres cas, par la signature de l’acte.
PRINCIPES GENERAUX D’ASSIETTE