Article 334 :
1) Les mutations à titre onéreux de fonds de commerce ou de clientèle, d’un office ou d’une charge sont soumises à un droit de 5%.
195
2) Ce droit est perçu sur le prix de vente de la clientèle, de l’achalandage, de la
cession du droit au bail et des objets mobiliers ou autres servant à l’exploitation du fonds. Ces objets doivent donner lieu à un inventaire détaillé et estimatif dans un état distinct dont trois (3) exemplaires doivent rester déposés au service des impôts où la formalité est requise.
3) Les ventes de stock de marchandises corrélatives à la cession d’un fonds de
commerce  sont  exonérées  de  droits  d’enregistrement  lorsqu’elles  donnent  lieu  à  la perception de la taxe sur la valeur ajoutée.
Dans le cas contraire, ces marchandises sont assujetties à un droit de 2%, à condition qu’il soit stipulé, en ce qui les concerne, un prix particulier, et qu’elles soient désignées et estimées article par article, dans un état distinct joint à l’acte enregistré. Lorsque ces conditions ne sont pas remplies, le droit général de 5% s’applique.
4) La  mutation  de  propriété  des  fonds  de  commerce  ou  des  clientèles  est
suffisamment établie pour la demande et la poursuite des droits d’enregistrement et des amendes, par les actes ou écrits qui révèlent l’existence de la mutation ou qui sont destinés à  la  rendre  publique,  ainsi  que  par  l’établissement  des  impôts  au  nom  du  nouveau possesseur, sauf preuve contraire.