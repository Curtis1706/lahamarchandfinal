Article 254 :
1) La demande de remboursement doit être adressée au directeur général des impôts au plus tard le dernier jour du mois suivant le délai précisé à l’article précédent.
2) Le remboursement ne peut être obtenu que si l’assujetti n’est pas redevable, vis-à-
vis du trésor public, d’une somme quelconque due au titre des impôts et taxes de toute nature.
3) La demande est accompagnée d’un exemplaire :
1) des documents portant taxe sur la valeur ajoutée déductible ;
1) des déclarations d’exportation ;
1) des  titres  d’exportation  dûment  signés  des  responsables  de  la  banque
domiciliataire des sommes provenant des ventes à l’étranger et du bureau des douanes ayant constaté le franchissement des marchandises ;
4) de la facture d’acquisition de biens d’investissement ;
4) ou de toutes pièces justificatives.
Toutefois, en attendant la création des conditions pour le rapatriement par une banque domiciliataire, des sommes provenant des ventes à un État de la Communauté économique des États de l’Afrique de l’ouest, utilisant une monnaie autre que le franc CFA, la  présentation  des  titres  d’exportation  dûment  signés  prévus  au  point  c  du  présent paragraphe n’est pas exigée pour le remboursement du crédit de taxe sur la valeur ajoutée lié à ces exportations.