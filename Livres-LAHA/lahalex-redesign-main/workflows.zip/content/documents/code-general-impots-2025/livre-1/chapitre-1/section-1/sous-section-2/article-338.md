Article 338 :
(Modifié par la loi de finances pour 2025) Sont enregistrés gratis :
- les ventes privées et aux enchères des œuvres d’art ;
- les actes portant cession d’obligations et de créances négociables.