Article 520 :
1) Le droit de communication peut être exercé par correspondance ou
sur place.
2) Lorsque l’administration fiscale entend exercer son droit de communication sur
place, elle est tenue d’adresser au plus tard, à la date de la première intervention, un avis de passage.
3) L’avis de passage précise la nature des documents qui doivent être mis à la
disposition de l’administration fiscale et porte la mention expresse qu’il s’agit de l’exercice du droit de communication et non d’une vérification de comptabilités.