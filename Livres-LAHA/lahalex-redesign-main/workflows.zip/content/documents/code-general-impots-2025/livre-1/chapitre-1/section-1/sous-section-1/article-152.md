Article 152 :
Sont soumises à la contribution, les propriétés foncières bâties ou non
bâties.
1) Les propriétés bâties sont les constructions fixées au sol à demeure, telles que
maisons, fabriques, manufactures, usines et en général tous les immeubles construits en maçonnerie, fer, bois ou autres matériaux.
Sont  assimilés  aux  propriétés  bâties  les  terrains  non  cultivés,  employés  à  usage commercial ou industriel, tels que chantiers, lieux de dépôts de marchandises et autres emplacements de même nature.
2) Constituent des propriétés non bâties et imposées comme telles, les terrains nus non
bâtis de toutes natures sises en République du Bénin à l’exception de celles qui en sont expressément exonérées.
Sont assimilés aux propriétés non bâties, les constructions légères, notamment les kiosques, tonnelles, pavillons, guérites, cases construites en paille, en banco, simplement posées sur le sol ou démunies de fondations en maçonnerie. Toutefois, si ces constructions sont productives de revenus ou affectées à un usage commercial, elles sont imposables suivant le régime des propriétés bâties.