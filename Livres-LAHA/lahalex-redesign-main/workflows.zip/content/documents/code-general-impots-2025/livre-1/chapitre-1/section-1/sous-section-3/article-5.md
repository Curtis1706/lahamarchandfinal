Article 5 :
1) L’impôt sur les sociétés est dû à raison des bénéfices réalisés dans les entreprises exploitées en République du Bénin ainsi que de ceux dont l’imposition est attribuée au Bénin par une convention internationale visant l’élimination des doubles impositions.
2) Sont réputées exploitées en République du Bénin :
1) les sociétés et autres entités résidentes en République du Bénin, c’est-à-dire
celles dont le siège social ou le lieu de direction effective est situé en République du Bénin ;
2) les sociétés et autres entités non-résidentes disposant d’un établissement
stable en République du Bénin.
3) Dans le cas visé au point 2) b), les bénéfices de la société non-résidente sont
imposables en République du Bénin où est situé son établissement stable, mais uniquement dans la mesure où ils sont imputables :
1) à cet établissement stable ; ou
2) aux ventes, en République du Bénin, de marchandises de même nature ou
de nature analogue que celles qui sont vendues par cet établissement stable ; ou
3) à d’autres activités industrielles ou commerciales exercées en République du
Bénin et de même nature ou de nature analogue à celles qui sont exercées par cet établissement stable.