Article 320 :
1) Tous les actes visés à l’article 318 ci-dessus, doivent être enregistrés en République du Bénin s’ils sont passés ou utilisés sur le territoire national.
2) Sont  obligatoirement  soumis  à  la  formalité  et  aux  droits  d’enregistrement  en
République du Bénin, les actes passés à l’étranger et portant :
1) sur des immeubles, fonds de commerce ou droit au bail sis en République du
Bénin ;
2) sur des titres de sociétés immatriculées en République du Bénin.
3) Les actes passés en République du Bénin et portant sur un immeuble, un fonds de
commerce, un droit au bail ou des titres de sociétés sis ou immatriculés hors du Bénin, ne sont soumis à la formalité de l’enregistrement en République du Bénin que sur présentation volontaire des parties.