Article  230 :
Sont  également  exonérées  de  la  taxe  sur  la  valeur  ajoutée  par application d’un taux zéro à la base d’imposition, les exportations de produits et de marchandises auxquelles sont assimilés :
1) Les affaires de vente, de réparation ou de transformation portant sur des bâtiments
destinés à la navigation maritime et immatriculés comme tels.
2) Les ventes aux compagnies de navigation et aux pêcheurs professionnels de
produits destinés à être incorporés dans leurs bâtiments ou à l’entretien de ceux-ci, ainsi que d’engins et de filets pour la pêche maritime.
3) L’avitaillement des navires et aéronefs à destination de l’étranger.
3) Les affaires de vente, de réparation, de transformation et d’entretien d’aéronefs
destinés  aux  compagnies  de  navigation  aérienne  dont  les  services  à  destination  de l’étranger représentent au moins 60% de l’ensemble des lignes qu’elles exploitent.
5) Les entrées en entrepôt fictif, en entrepôt réel, en entrepôt spécial ou tout autre
régime suspensif, dans les mêmes conditions que pour les droits d’entrée et sous réserve d’exportation effective des biens concernés.
6) Les prestations de services liées aux biens placés sous le régime douanier du transit,
à l’exception de celles réalisées en République du Bénin lorsque le prestataire y a le siège ![](Aspose.Words.396e98ff-4ef7-480c-af9c-eea1aad41a7c.004.png)
sAutres exonérations de TVA prévues par la loi de finances pour 2024 :
1) Exonérations  temporaires  du  1er  janvier  au  31  décembre  2024  de  l’importation,  la
fabrication et la vente de : véhicules neufs à quatre roues. Cette mesure s’applique aux camions, autobus,  autocars  et  minibus  de  toutes  catégories,  voitures  de  tourisme  et  autres  véhicules automobiles conçus pour le transport des personnes, y compris les voitures de type « break » double cabine. ; aéronefs et  les  aérostats, ainsi que  leurs pièces  de rechange ;  récipients pour gaz comprimés ou liquéfiés, en fonte, fer ou acier et les accessoires (brûleurs, supports marmites pour les bouteilles de 3 et 6 kg, tuyaux, raccords, détendeurs, réchauds à gaz sans four et robinet- détendeurs) pour gaz domestique ; équipements et matériaux neufs importés en République du Bénin, ainsi que les matériaux locaux, destinés à la construction des stations-services, des stations- trottoirs, des cuves à pétrole et à gasoil ; les équipements neufs importés pour la rénovation des stations-services, des stations-trottoirs, des cuves à pétrole et à gasoil.
2) Exonération permanente de l’importation des matériels et équipements neufs importés en
République du Bénin par les PME ne bénéficiant pas d’un régime fiscal dérogatoire, destinés à l’installation d’unités artisanales et industrielles.
de son activité ou un établissement stable à partir duquel le service est rendu ou, à défaut, son domicile ou sa résidence habituelle.
Pour  la  réalisation  des  opérations  visées  ci-dessus,  les  entreprises  exportatrices bénéficient du droit à déduction de la taxe sur la valeur ajoutée acquittée auprès des fournisseurs dans les conditions prévues par les articles 243 et suivants du présent code.