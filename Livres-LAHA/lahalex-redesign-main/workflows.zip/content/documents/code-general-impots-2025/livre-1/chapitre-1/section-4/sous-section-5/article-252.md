Article 252 :
1) Si le montant de la déduction autorisée est supérieur au montant de la taxe exigible au titre d’une déclaration donnée, l’excédent constitue un crédit d’impôt imputable sur la taxe exigible pour la période suivante.
2) Les crédits d’impôt générés par le mécanisme des déductions sont imputables sur
la taxe sur la valeur ajoutée due pour les périodes ultérieures jusqu’à épuisement, sans limitation de délai.
3) Les crédits de taxe sur la valeur ajoutée ne peuvent pas être remboursés à
l’assujetti, sauf dans les cas prévus à l’article 253 ci-dessous.