Article 24 :
Les rétributions de toute nature versées aux gérants ou administrateurs sont déductibles à condition :
1) que ces rémunérations correspondent à un travail effectif ;
1) qu’elles ne soient pas excessives eu égard à l’importance de l’activité exercée ;
1) qu’elles  soient  soumises  à  l’impôt  sur  les  traitements  et  salaires  au  nom  des
bénéficiaires.