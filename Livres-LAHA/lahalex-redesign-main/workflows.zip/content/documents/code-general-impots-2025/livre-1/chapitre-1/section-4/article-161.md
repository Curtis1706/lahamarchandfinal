Article 161 :
1) Les contribuables sont tenus de déclarer leurs propriétés foncières, par simple lettre, au service des impôts, dans un délai de trente (30) jours suivant l’acquisition ou l’achèvement des constructions desdites propriétés.
2) Ils sont astreints à la pose d’une plaque signalétique sur leurs propriétés non bâties
ou à l’inscription d’une mention à l’entrée de leurs constructions, comportant l’adresse complète précisant obligatoirement le numéro « Rue entrée de la parcelle ».
3) Les  propriétaires  et  principaux  locataires  et  en  leur  lieu  et  place  les  gérants
d’immeubles, sont tenus de fournir par écrit aux agents chargés de l’assiette de l’impôt, au plus tard le 10 décembre de chaque année, une déclaration indiquant au jour de sa production :
95