Article  325 :
1)  Lorsque  dans  un  acte  quelconque,  il  y  a  plusieurs  dispositions indépendantes ou ne dérivant pas nécessairement les unes des autres, il est dû pour chacune d’elles, et selon son espèce, un droit particulier.
La quotité des divers droits est déterminée par les dispositions du présent code. 2) Sont affranchies de la pluralité prévue au paragraphe 1 du présent article, les
dispositions indépendantes et non soumises au droit proportionnel.
Lorsqu’un acte contient plusieurs dispositions indépendantes, donnant ouverture, les unes au droit proportionnel, les autres à un droit fixe, le droit fixe n’est pas perçu, sauf
application du droit fixe le plus élevé comme minimum de perception si le montant des droits proportionnels exigibles est inférieur.