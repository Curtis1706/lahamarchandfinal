Article 249 :
1) Le prorata prévu à l’article 248 ci-dessus est le rapport entre :
1) au  numérateur,  le  montant  total  hors  taxes  des  recettes  ou  du  chiffre
d’affaires afférents à des opérations soumises à la taxe sur la valeur ajoutée, augmentée du montant des exportations des produits taxables ;
2) et au dénominateur, le montant total hors taxes du chiffre d’affaires ou des
recettes de toutes natures réalisées par l’assujetti.
2) Ne figurent pas dans la fraction permettant de calculer le prorata :
1) les livraisons à soi-même ;
1) les cessions d’immobilisations ;
1) les ventes de biens d’occasion ;
1) les subventions d’équipement ;
1) les remboursements de débours perçus par un mandataire et non soumis à
la taxe sur la valeur ajoutée ;
6) les indemnités ne constituant pas la contrepartie d’une opération soumise à
la taxe sur la valeur ajoutée.
3) Le prorata est arrondi à l’unité immédiatement supérieure.
3) Le  prorata  est  déterminé  provisoirement  en  fonction  du  chiffre  d’affaires  de
l’année précédente, ou pour les nouveaux assujettis, du chiffre d’affaires prévisionnel.
Toutes les déductions pratiquées sur la base d’un prorata provisoire au cours de l’exercice précédent doivent être régularisées, au plus tard le 30 avril de l’année suivante, en tenant compte du prorata définitif.