Article 275 :
Le fait générateur de la taxe est constitué :
1) pour les importations, par la mise à la consommation au sens douanier du terme ;
1) pour la production, par la première cession réalisée dans les conditions définies ci-
dessus.