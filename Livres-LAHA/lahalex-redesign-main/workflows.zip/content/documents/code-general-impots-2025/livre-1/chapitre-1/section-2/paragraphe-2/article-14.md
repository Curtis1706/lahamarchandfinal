Article 14 :
(Modifié par la loi de finances pour 2025) Sont exonérés de l’impôt sur les
sociétés :
1) les bonis provenant des opérations faites avec les associés et distribués à ces
derniers au prorata de la commande de chacun d’eux, en ce qui concerne les sociétés coopératives de consommation ;
2) la part des bénéfices nets qui est distribuée aux travailleurs, dans les conditions
prévues par les textes qui régissent les sociétés coopératives ouvrières de production ;
3) la part de bénéfices sociaux correspondant aux droits sociaux de l’entreprise dans
les sociétés à prépondérance immobilière.