Article  185 :
1)  La  taxe  professionnelle  synthétique  doit  être  payée  en  deux  (2) acomptes  provisionnels  calculés  sur  la  base  de  l’impôt  de  l’année  précédente.  Les paiements doivent être effectués spontanément dans les dix (10) premiers jours des mois de février et de juin de chaque année.
Les  entreprises  qui  deviennent  imposables  pour  la  première  fois  en  vertu  du paragraphe 3 de l’article 180 ci-dessus, paient l’impôt minimum prévu au paragraphe 2 de l’article 183 ci-dessus dans les dix (10) premiers jours du mois suivant celui au cours duquel la période d’exonération est échue.
2) Le solde éventuel est payé au plus tard le 30 avril lors de la souscription de la
déclaration.
3) les acomptes et les retenues éventuelles d’acompte sur impôt assis sur les bénéfices
sont  imputés  sur  la  déclaration  de  résultat.  Lorsque  la  déclaration  présente  un  solde créditeur, ce crédit est imputé sur les acomptes ultérieurs.