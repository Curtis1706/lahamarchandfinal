Article 322 :
1) Les droits proportionnels sont assis sur la valeur exprimée par les parties dans les actes et déclarations.
2) Toutefois, l’administration fiscale peut rectifier le prix ou l’évaluation d’un bien ayant
servi de base à la perception d’une imposition lorsque ce prix ou cette évaluation parait inférieur à la valeur vénale des biens transmis ou désignés dans les actes ou déclarations.
3) En cas de désaccord sur les valeurs entre les parties et l’administration fiscale, la
commission de conciliation prévue à l’article 560 du présent code peut être saisie.