Article 31 :
1) Sont déductibles :
1) les primes d’assurances contractées au profit de l’entreprise pour couvrir les
risques dont la réalisation entraîne directement et par elle-même, une diminution de l’actif net ;
2) les primes d’assurances constituant par elles-mêmes une charge d’exploitation ;
2) les primes d’assurance-maladie versées aux sociétés d’assurance au profit
de l’ensemble du personnel lorsque ne figurent pas dans les charges déductibles, les remboursements de frais de cette nature au profit des mêmes personnes.
2) Les sommes constituées par l’entreprise en vue de sa propre assurance ne sont pas
déductibles.
3) Les  primes  d’assurance  relatives  aux  indemnités  de  fin  de  carrière  (IFC)  sont
déductibles à condition que :
1) le versement de la prime relève d’une obligation prévue par la législation
sociale en vigueur en République du Bénin ;
2) le contrat d’assurance présente un caractère général, c’est-à-dire concerne
l’ensemble du personnel ou une ou plusieurs catégories déterminées de ce personnel ;
3) la prime soit versée à une société d’assurance installée en République du Bénin ;
4) l’entreprise qui a versé la prime d’assurances relative aux indemnités de fin
de carrière ne conserve ni la propriété, ni la libre disposition des fonds.