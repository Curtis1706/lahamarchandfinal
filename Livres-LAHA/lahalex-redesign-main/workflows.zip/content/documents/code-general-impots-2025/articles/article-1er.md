Article 1er : 1) L’assiette, la liquidation, le contrôle et les modalités de recouvrement des impositions de toute nature sont du domaine de la loi.
2) Les règles d’assiette, de liquidation et de recouvrement des impôts, droits et taxes
visés par le présent code sont applicables sous réserve des dispositions des conventions internationales régulièrement ratifiées par le Bénin.
3) Sont nuls et de nul effet, tous avantages fiscaux, toutes exonérations d’impôts, droits
et taxes non prévus par la loi.