'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import { ChevronDown, ChevronRight, FileText, Folder, Search } from 'lucide-react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useSmartScroll } from '@/hooks/useSmartScroll'
import type { DocumentMetadata, DocumentSection } from '@/types/document'

interface DocumentSidebarProps {
  document: DocumentMetadata
  currentArticle?: string
  className?: string
}

export function DocumentSidebar({ document, currentArticle, className = '' }: DocumentSidebarProps) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set())
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredSections, setFilteredSections] = useState(document.structure.sections)
  const { scrollToElement } = useSmartScroll()
  const sidebarRef = useRef<HTMLDivElement>(null)

  const updateExpandedSections = useCallback(() => {
    if (currentArticle && document.structure.sections) {
      const newExpanded = new Set(expandedSections)
      
      const findParentSections = (articleId: string) => {
        // Logique pour trouver les sections parentes
        document.structure.sections.forEach(section => {
          if (section.children.includes(articleId) || section.id === articleId) {
            newExpanded.add(section.id)
            if (section.parent) {
              newExpanded.add(section.parent)
            }
          }
        })
      }
      
      findParentSections(currentArticle)
      
      // Seulement mettre à jour si il y a vraiment des changements
      const hasChanges = newExpanded.size !== expandedSections.size || 
        [...newExpanded].some(id => !expandedSections.has(id))
      
      if (hasChanges) {
        setExpandedSections(newExpanded)
      }
    }
  }, [currentArticle, document.structure.sections, expandedSections])

  useEffect(() => {
    updateExpandedSections()
  }, [currentArticle]) // Seulement quand currentArticle change

  useEffect(() => {
    // Scroll séparé
    if (currentArticle) {
      setTimeout(() => {
        const currentElement = sidebarRef.current?.querySelector(`[data-article-id="${currentArticle}"]`)
        if (currentElement) {
          scrollToElement(currentElement as HTMLElement, { block: 'nearest' })
        }
      }, 100)
    }
  }, [currentArticle, scrollToElement])

  // Filtrer les sections selon la recherche
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredSections(document.structure.sections)
      return
    }

    const filtered = document.structure.sections.filter(section =>
      section.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
    
    setFilteredSections(filtered)
    
    // Auto-expand les sections qui matchent
    const newExpanded = new Set(expandedSections)
    filtered.forEach(section => {
      newExpanded.add(section.id)
      // Développer aussi les parents
      if (section.parent) {
        newExpanded.add(section.parent)
      }
    })
    setExpandedSections(newExpanded)
  }, [searchTerm, document.structure.sections])

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections)
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId)
    } else {
      newExpanded.add(sectionId)
    }
    setExpandedSections(newExpanded)
  }

  const renderSection = (section: DocumentSection, level: number = 0) => {
    const isExpanded = expandedSections.has(section.id)
    const hasChildren = section.children.length > 0
    const indent = level * 16
    const isCurrent = section.id === currentArticle
    const isHighlighted = searchTerm && section.title.toLowerCase().includes(searchTerm.toLowerCase())

    return (
      <div key={section.id} className="select-none">
        <div
          data-article-id={section.type === 'article' ? section.id : undefined}
          className={`flex items-center py-2 px-3 cursor-pointer transition-colors ${
            isCurrent 
              ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-500' 
              : 'hover:bg-gray-100'
          } ${isHighlighted ? 'bg-yellow-50' : ''}`}
          style={{ paddingLeft: `${12 + indent}px` }}
          onClick={() => hasChildren && toggleSection(section.id)}
        >
          {hasChildren ? (
            isExpanded ? (
              <ChevronDown className="w-4 h-4 mr-2 text-gray-500" />
            ) : (
              <ChevronRight className="w-4 h-4 mr-2 text-gray-500" />
            )
          ) : (
            <div className="w-6 mr-2" />
          )}
          
          {section.type === 'article' ? (
            <FileText className="w-4 h-4 mr-2 text-blue-500" />
          ) : (
            <Folder className="w-4 h-4 mr-2 text-gray-600" />
          )}
          
          {section.type === 'article' ? (
            <Link
              href={`/documents/${document.id}/${section.id}`}
              className="text-sm text-blue-600 hover:underline flex-1 truncate"
              onClick={(e) => e.stopPropagation()}
            >
              {section.title}
            </Link>
          ) : (
            <span className="text-sm text-gray-700 font-medium flex-1 truncate">
              {section.title}
            </span>
          )}
        </div>

        {isExpanded && hasChildren && (
          <div className="border-l border-gray-200 ml-6">
            {section.children.map((childId, index) => {
              const childSection = filteredSections.find(s => s.id === childId)
              return childSection ? (
                <div key={`${childSection.id}-${level}-${index}`}>
                  {renderSection(childSection, level + 1)}
                </div>
              ) : null
            })}
          </div>
        )}
      </div>
    )
  }

  return (
    <div ref={sidebarRef} className={`bg-white border-r border-gray-200 flex flex-col ${className}`}>
      {/* En-tête */}
      <div className="p-4 border-b border-gray-200 flex-shrink-0">
        <Link href="/documents" className="text-sm text-blue-600 hover:underline">
          ← Tous les documents
        </Link>
        <h2 className="font-semibold text-gray-900 mt-2 line-clamp-2">
          {document.title}
        </h2>
        <p className="text-xs text-gray-500 mt-1">
          {document.structure.totalArticles} articles
        </p>
      </div>

      {/* Barre de recherche */}
      <div className="p-3 border-b border-gray-200 flex-shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1">
        <div className="py-2">
          {filteredSections
            .filter(section => !section.parent) // Sections racines seulement
            .map((section, index) => (
              <div key={`root-${section.id}-${index}`}>
                {renderSection(section)}
              </div>
            ))}
        </div>
      </ScrollArea>
    </div>
  )
}







