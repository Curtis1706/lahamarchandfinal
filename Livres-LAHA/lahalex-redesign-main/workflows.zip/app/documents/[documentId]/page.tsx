import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { DocumentManager } from '@/lib/document-manager'
import { DocumentSidebar } from '@/components/DocumentSidebar'
import { Calendar, FileText, ExternalLink } from 'lucide-react'

interface DocumentPageProps {
  params: Promise<{ documentId: string }>
}

export async function generateMetadata({ params }: DocumentPageProps): Promise<Metadata> {
  const { documentId } = await params
  const document = await DocumentManager.loadDocument(documentId)
  
  if (!document) {
    return { title: 'Document non trouvé' }
  }

  return {
    title: `${document.title} - LAHALEX`,
    description: document.description
  }
}

export default async function DocumentPage({ params }: DocumentPageProps) {
  const { documentId } = await params
  const document = await DocumentManager.loadDocument(documentId)

  if (!document) {
    notFound()
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 flex-shrink-0">
        <DocumentSidebar document={document} />
      </div>

      {/* Contenu principal */}
      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto">
          {/* En-tête du document */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                  {document.title}
                </h1>
                <p className="text-lg text-gray-600 leading-relaxed">
                  {document.description}
                </p>
              </div>
              
              <div className="ml-6 flex-shrink-0">
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                  document.type === 'constitution' ? 'bg-purple-100 text-purple-800' :
                  document.type === 'code' ? 'bg-blue-100 text-blue-800' :
                  document.type === 'loi' ? 'bg-green-100 text-green-800' :
                  document.type === 'decret' ? 'bg-orange-100 text-orange-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {document.type === 'constitution' ? 'Constitution' :
                   document.type === 'code' ? 'Code' :
                   document.type === 'loi' ? 'Loi' :
                   document.type === 'decret' ? 'Décret' : 'Document'}
                </span>
              </div>
            </div>

            {/* Métadonnées */}
            <div className="flex flex-wrap gap-6 text-sm text-gray-600">
              <div className="flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                {document.structure.totalArticles} articles
              </div>
              
              {document.publishedDate && (
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Publié le {new Date(document.publishedDate).toLocaleDateString('fr-FR')}
                </div>
              )}
              
              {document.source && (
                <div className="flex items-center">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Source: {document.source}
                </div>
              )}
            </div>
          </div>

          {/* Instructions de navigation */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-blue-900 mb-3">
              Navigation du document
            </h2>
            <p className="text-blue-800 mb-4">
              Utilisez le menu de gauche pour naviguer dans la structure hiérarchique du document. 
              Cliquez sur les sections pour les développer et accéder aux articles individuels.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                📁 Sections pliables
              </span>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                📄 Articles cliquables
              </span>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                🔗 Navigation directe
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
