import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, Home } from 'lucide-react'
import { DocumentManager } from '@/lib/document-manager'
import { DocumentSidebar } from '@/components/DocumentSidebar'
import { SearchBar } from '@/components/SearchBar'
import { processMarkdownContent } from '@/lib/text-processor'

interface ArticlePageProps {
  params: { 
    documentId: string
    articlePath: string[]
  }
}

export async function generateMetadata({ params }: ArticlePageProps): Promise<Metadata> {
  const { documentId, articlePath } = await params
  const articleId = articlePath[articlePath.length - 1]
  const article = await DocumentManager.loadArticle(documentId, articleId)
  const document = await DocumentManager.loadDocument(documentId)

  if (!article || !document) {
    return { title: 'Article non trouvé' }
  }

  return {
    title: `${article.metadata.title} - ${document.title}`,
    description: `Article ${article.metadata.numero} du ${document.title}`
  }
}

export default async function ArticlePage({ params }: ArticlePageProps) {
  const { documentId, articlePath } = await params
  const articleId = articlePath[articlePath.length - 1]
  const [document, article] = await Promise.all([
    DocumentManager.loadDocument(documentId),
    DocumentManager.loadArticle(documentId, articleId)
  ])

  if (!document || !article) {
    notFound()
  }

  const processedContent = await processMarkdownContent(article.content)

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 flex-shrink-0 h-screen sticky top-0">
        <DocumentSidebar 
          document={document} 
          currentArticle={articleId}
          className="h-full"
        />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Link href="/" className="hover:text-blue-600">
                <Home className="w-4 h-4" />
              </Link>
              <span>/</span>
              <Link
                href={`/documents/${documentId}`}
                className="hover:text-blue-600 truncate"
              >
                {document.title}
              </Link>
              <span>/</span>
              <span className="text-gray-900 font-medium truncate">
                {article.metadata.title}
              </span>
            </div>
            <SearchBar />
          </div>
        </div>

        {/* Content area */}
        <div className="flex-1 p-6">
          {/* Navigation */}
          <div className="flex justify-between items-center mb-6">
            {article.metadata.navigation.previous ? (
              <Link
                href={`/documents/${documentId}/${article.metadata.navigation.previous}`}
                className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Article précédent
              </Link>
            ) : (
              <div />
            )}

            {article.metadata.navigation.next ? (
              <Link
                href={`/documents/${documentId}/${article.metadata.navigation.next}`}
                className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                Article suivant
                <ChevronRight className="w-4 h-4 ml-2" />
              </Link>
            ) : (
              <div />
            )}
          </div>

          {/* Article content */}
          <article className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
            <header className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {article.metadata.title}
              </h1>
              <div className="text-sm text-gray-600">
                Article {article.metadata.numero}
              </div>
            </header>

            <div 
              className="prose max-w-none legal-document"
              dangerouslySetInnerHTML={{ __html: processedContent }}
            />
          </article>
        </div>
      </div>
    </div>
  )
}


