"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { LahalexHeaderResponsive } from "@/components/lahalex-header-responsive"
import { LahalexBreadcrumbResponsive } from "@/components/lahalex-breadcrumb-responsive"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChevronDown, Search, Bell, Filter, Heart } from 'lucide-react'
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { fr } from "date-fns/locale"

interface Article {
  id: string
  title: string
  slug: string
  description: string
  summary: string
  source: string
  publishedAt: string
  category: {
    id: string
    name: string
    slug: string
    color: string
  }
  tags: Array<{
    id: string
    name: string
    slug: string
    color: string
  }>
  author: {
    id: string
    name: string
  }
  favoritesCount: number
  createdAt: string
}

interface Category {
  id: string
  name: string
  slug: string
  description: string
  color: string
  articlesCount: number
  children: Array<{
    id: string
    name: string
    slug: string
    description: string
    color: string
    articlesCount: number
  }>
}

export default function VeilleJuridiquePage() {
  const [searchValue, setSearchValue] = useState("")
  const [articles, setArticles] = useState<Article[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [sortBy, setSortBy] = useState("publishedAt")
  const [sortOrder, setSortOrder] = useState("desc")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set())
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  // Charger les catégories
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("/api/categories")
        const data = await response.json()
        setCategories(data.categories)
      } catch (error) {
        console.error("Erreur lors du chargement des catégories:", error)
      }
    }

    fetchCategories()
  }, [])

  // Charger les articles
  useEffect(() => {
    const fetchArticles = async () => {
      setLoading(true)
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "10",
          sortBy,
          sortOrder,
          ...(selectedCategory !== "all" && { category: selectedCategory }),
          ...(searchQuery && { search: searchQuery }),
        })

        const response = await fetch(`/api/articles?${params}`)
        const data = await response.json()

        setArticles(data.articles)
        setTotalPages(data.pagination.pages)
      } catch (error) {
        console.error("Erreur lors du chargement des articles:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchArticles()
  }, [page, sortBy, sortOrder, selectedCategory, searchQuery])

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections)
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId)
    } else {
      newExpanded.add(sectionId)
    }
    setExpandedSections(newExpanded)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setSearchQuery(searchValue)
    setPage(1)
  }

  const handleSortChange = (newSortBy: string) => {
    if (newSortBy === sortBy) {
      setSortOrder(sortOrder === "desc" ? "asc" : "desc")
    } else {
      setSortBy(newSortBy)
      setSortOrder("desc")
    }
    setPage(1)
  }

  // Breadcrumb for the new home page
  const breadcrumbItems = [{ label: "Veille juridique", isActive: true }]

  return (
    <div className="min-h-screen bg-white">
      <LahalexHeaderResponsive searchValue={searchValue} onSearchChange={setSearchValue} />
      <LahalexBreadcrumbResponsive items={breadcrumbItems} />

      <div className="container-responsive py-4 sm:py-6">
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-8">
          {/* Sidebar gauche */}
          <div className="lg:w-80 lg:flex-shrink-0">
            {/* Mobile: Bouton pour ouvrir les filtres */}
            <div className="lg:hidden mb-4">
              <Button
                variant="outline"
                className="w-full justify-between bg-transparent"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <span className="flex items-center">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtres
                </span>
                <ChevronDown className={`w-4 h-4 transition-transform ${sidebarOpen ? "rotate-180" : ""}`} />
              </Button>
            </div>

            {/* Sidebar content */}
            <div className={`${sidebarOpen ? "block" : "hidden"} lg:block space-y-4 lg:space-y-6`}>
              <h2 className="text-lg sm:text-xl font-semibold text-gray-900 hidden lg:block">Veille juridique</h2>

              {/* Barre de recherche */}
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    type="text"
                    placeholder="Taper des mots-clés"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    className="pl-10 border-gray-300 text-sm sm:text-base"
                  />
                </div>
              </form>

              {/* Filtres par catégorie */}
              <div className="space-y-3 sm:space-y-4">
                <Button
                  variant={selectedCategory === "all" ? "default" : "outline"}
                  className="w-full justify-start text-left text-sm sm:text-base"
                  onClick={() => {
                    setSelectedCategory("all")
                    setPage(1)
                  }}
                >
                  Toutes les catégories
                </Button>

                {categories.map((category) => (
                  <div key={category.id}>
                    <Button
                      variant={selectedCategory === category.slug ? "default" : "outline"}
                      className="w-full justify-between text-left text-sm sm:text-base bg-transparent"
                      onClick={() => toggleSection(category.slug)}
                    >
                      <span className="flex items-center">
                        <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: category.color }} />
                        {category.name}
                        <Badge variant="secondary" className="ml-2">
                          {category.articlesCount}
                        </Badge>
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${expandedSections.has(category.slug) ? "rotate-180" : ""}`}
                      />
                    </Button>

                    {expandedSections.has(category.slug) && category.children.length > 0 && (
                      <div className="ml-4 mt-2 space-y-1">
                        {category.children.map((child) => (
                          <Button
                            key={child.id}
                            variant={selectedCategory === child.slug ? "default" : "ghost"}
                            className="w-full justify-start text-left text-xs sm:text-sm"
                            onClick={() => {
                              setSelectedCategory(child.slug)
                              setPage(1)
                            }}
                          >
                            <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: child.color }} />
                            {child.name}
                            <Badge variant="outline" className="ml-auto">
                              {child.articlesCount}
                            </Badge>
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Contenu principal */}
          <div className="flex-1 min-w-0">
            {/* Contrôles de tri */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4 mb-4 sm:mb-6">
              <div className="flex items-center space-x-2 sm:space-x-4 w-full sm:w-auto">
                <select
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [newSortBy, newSortOrder] = e.target.value.split("-")
                    setSortBy(newSortBy)
                    setSortOrder(newSortOrder)
                    setPage(1)
                  }}
                  className="border border-gray-300 rounded-md px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm flex-1 sm:flex-none"
                >
                  <option value="publishedAt-desc">Tri: Plus récent</option>
                  <option value="publishedAt-asc">Tri: Plus ancien</option>
                  <option value="title-asc">Tri: Titre A-Z</option>
                  <option value="title-desc">Tri: Titre Z-A</option>
                </select>
              </div>

              <div className="flex items-center space-x-2 w-full sm:w-auto">
                <Bell className="w-4 h-4 text-gray-600 flex-shrink-0" />
                <select className="border border-gray-300 rounded-md px-2 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm flex-1 sm:flex-none">
                  <option>Alerte</option>
                  <option>Notification</option>
                </select>
              </div>
            </div>

            {/* Liste des articles */}
            {loading ? (
              <div className="space-y-6">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-3"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3 mb-4"></div>
                    <div className="flex space-x-2">
                      <div className="h-6 bg-gray-200 rounded w-20"></div>
                      <div className="h-6 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : articles.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">Aucun article trouvé pour les critères sélectionnés.</p>
              </div>
            ) : (
              <div className="space-y-6 sm:space-y-8">
                {articles.map((article) => (
                  <article key={article.id} className="border-b border-gray-200 pb-4 sm:pb-6">
                    <div className="mb-2 flex items-center space-x-2">
                      <span className="text-xs sm:text-sm text-gray-600">
                        {format(new Date(article.publishedAt), "dd MMMM yyyy", { locale: fr })}
                      </span>
                      {article.source && (
                        <>
                          <span className="text-gray-400">•</span>
                          <span className="text-xs sm:text-sm text-gray-600">{article.source}</span>
                        </>
                      )}
                    </div>

                    <Link href={`/article/${article.slug}`}>
                      <h3 className="text-lg sm:text-xl font-semibold text-primary-lahalex mb-3 hover:underline cursor-pointer leading-tight">
                        {article.title}
                      </h3>
                    </Link>

                    <p className="text-sm sm:text-base text-gray-700 mb-4 leading-relaxed">{article.description}</p>

                    <div className="mb-4 flex flex-wrap items-center gap-2">
                      <Badge style={{ backgroundColor: article.category.color }} className="text-white">
                        {article.category.name}
                      </Badge>
                      {article.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag.id} variant="outline">
                          {tag.name}
                        </Badge>
                      ))}
                      {article.tags.length > 3 && <Badge variant="outline">+{article.tags.length - 3}</Badge>}
                    </div>

                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-2 sm:space-y-0">
                      <div className="flex items-center space-x-4">
                        <Link
                          href={`/article/${article.slug}`}
                          className="text-blue-600 hover:text-blue-800 text-sm sm:text-base hover:underline"
                        >
                          Lire l'article
                        </Link>
                        <Button variant="link" className="text-blue-600 hover:text-blue-800 p-0 text-sm sm:text-base">
                          <Heart className="w-4 h-4 mr-1" />
                          Ajouter aux favoris
                        </Button>
                      </div>

                      <div className="flex items-center space-x-2 text-xs text-gray-500">
                        <Heart className="w-3 h-3" />
                        <span>{article.favoritesCount} favoris</span>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center space-x-2 mt-8">
                <Button variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)}>
                  Précédent
                </Button>

                <div className="flex space-x-1">
                  {[...Array(Math.min(5, totalPages))].map((_, i) => {
                    const pageNum = i + 1
                    return (
                      <Button
                        key={pageNum}
                        variant={page === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setPage(pageNum)}
                      >
                        {pageNum}
                      </Button>
                    )
                  })}
                </div>

                <Button variant="outline" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
                  Suivant
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer responsive */}
      <footer className="bg-primary-lahalex text-white py-4 sm:py-6 mt-8 sm:mt-12">
        <div className="container-responsive">
          <div className="footer-links">
            <span>CONDITIONS GÉNÉRALES DE VENTE ET D'UTILISATION</span>
            <span>POLITIQUES DE CONFIDENTIALITÉS</span>
            <span>COPYRIGHT 2025 LAHALEX TOUS DROITS RÉSERVÉS</span>
            <span>POUR DE L'ASSISTANCE : XXXXXXXXX</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
