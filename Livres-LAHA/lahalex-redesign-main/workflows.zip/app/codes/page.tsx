"use client"

import { useState } from "react"
import { LahalexHeaderResponsive } from "@/components/lahalex-header-responsive"
import { LahalexBreadcrumbResponsive } from "@/components/lahalex-breadcrumb-responsive"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChevronRight, ChevronDown, PrinterIcon as Print, Download, Share2, Search } from "lucide-react"
import Link from "next/link"

export default function CodesPage() {
  const [searchValue, setSearchValue] = useState("")
  const [documentSearch, setDocumentSearch] = useState("")
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["livre-1", "titre-1"]))

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections)
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId)
    } else {
      newExpanded.add(sectionId)
    }
    setExpandedSections(newExpanded)
  }

  const breadcrumbItems = [
    { label: "Textes", href: "/textes" },
    { label: "Sources nationales", href: "/textes/sources-nationales" },
    { label: "Codes", href: "/codes" },
    { label: "Code Général des Impôts (CGI) : Fiscalité directe et indirecte", isActive: true },
  ]

  const codeStructure = [
    {
      id: "article-1",
      title: "Article 1",
      type: "article",
    },
    {
      id: "livre-1",
      title: "Livre 1 : Impôts directs",
      type: "livre",
      children: [
        {
          id: "titre-1",
          title: "Titre 1: Impôts sur le revenu",
          type: "titre",
          children: [
            { id: "chapitre-1", title: "Chapitre 1", type: "chapitre", isActive: true },
            { id: "chapitre-2", title: "Chapitre 2", type: "chapitre" },
            { id: "chapitre-3", title: "Chapitre 3", type: "chapitre" },
            { id: "chapitre-4", title: "Chapitre 4", type: "chapitre" },
            { id: "chapitre-5", title: "Chapitre 5", type: "chapitre" },
            { id: "chapitre-6", title: "Chapitre 6", type: "chapitre" },
            { id: "chapitre-7", title: "Chapitre 7", type: "chapitre" },
            { id: "chapitre-8", title: "Chapitre 8", type: "chapitre" },
          ],
        },
        {
          id: "titre-2",
          title: "Titre 2 : Taxes sur le patrimoine",
          type: "titre",
        },
        {
          id: "titre-3",
          title: "Titre 3 : Autres impôts directs et taxes assimilées",
          type: "titre",
        },
      ],
    },
    {
      id: "finir",
      title: "( à finir )",
      type: "note",
      className: "text-red-600",
    },
  ]

  const renderStructureItem = (item: any, level = 0) => {
    const hasChildren = item.children && item.children.length > 0
    const isExpanded = expandedSections.has(item.id)
    const paddingLeft = level * 16

    return (
      <div key={item.id}>
        {hasChildren ? (
          <button
            onClick={() => toggleSection(item.id)}
            className="w-full flex items-center p-2 text-left hover:bg-gray-50 rounded"
            style={{ paddingLeft: `${paddingLeft}px` }}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 mr-2 flex-shrink-0" />
            ) : (
              <ChevronRight className="w-4 h-4 mr-2 flex-shrink-0" />
            )}
            <span className={`text-sm ${item.className || "text-gray-900"}`}>{item.title}</span>
          </button>
        ) : (
          <Link
            href={`/codes/cgi/${item.id}`}
            className={`block p-2 text-sm hover:underline ${
              item.isActive ? "bg-primary-lahalex text-white font-medium" : item.className || "text-blue-600"
            }`}
            style={{ paddingLeft: `${paddingLeft + 24}px` }}
          >
            {item.title}
          </Link>
        )}

        {hasChildren && isExpanded && (
          <div>{item.children.map((child: any) => renderStructureItem(child, level + 1))}</div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <LahalexHeaderResponsive searchValue={searchValue} onSearchChange={setSearchValue} />
      <LahalexBreadcrumbResponsive items={breadcrumbItems} />

      <div className="container-responsive py-4 sm:py-6">
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-8">
          {/* Sidebar gauche */}
          <div className="lg:w-80 lg:flex-shrink-0 bg-gray-50 p-4 rounded-lg">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Codes</h2>

            <div className="space-y-1">{codeStructure.map((item) => renderStructureItem(item))}</div>
          </div>

          {/* Contenu principal */}
          <div className="flex-1">
            <div className="mb-6">
              <div className="text-sm text-gray-600 mb-2">LOI N°2021-15 DU 23 DÉCEMBRE 2021</div>
              <div className="text-sm text-gray-600 mb-4">
                portant code général des impôts de la République du Bénin
              </div>
            </div>

            <div className="mb-8">
              <h1 className="text-2xl font-semibold text-gray-900 mb-6">Chapitre 1 : Impôt sur les sociétés (IS)</h1>

              <h2 className="text-xl font-semibold text-gray-900 mb-4">Article 2</h2>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Les bénéfices réalisés par les sociétés et autres personnes morales désignées par le présent chapitre
                  sont soumis à un impôt annuel dénommé impôt sur les sociétés.
                </p>

                <h2 className="text-xl font-semibold text-gray-900 mb-4">Section 1 : Champ d'application</h2>

                <h3 className="text-lg font-semibold text-gray-900 mb-4">Sous-section 1 : Personnes imposables</h3>

                <h4 className="text-base font-semibold text-gray-900 mb-4">Article 3</h4>

                <p className="text-gray-700 leading-relaxed mb-4">Sont passibles de l'impôt sur les sociétés :</p>

                <div className="ml-6 mb-6">
                  <p className="text-gray-700 mb-3">
                    <strong>1. En raison de leur forme :</strong>
                  </p>
                  <div className="ml-6 space-y-2">
                    <p className="text-gray-700">
                      a) les sociétés anonymes, les sociétés par actions simplifiées, les sociétés à responsabilité
                      limitée et les sociétés en commandite simple ;
                    </p>
                    <p className="text-gray-700">
                      b) les sociétés coopératives, les groupements et leurs unions et fédérations, ainsi que les
                      confédérations des sociétés coopératives et des groupements, quelles que soient leurs activités ;
                    </p>
                    <p className="text-gray-700">
                      c) toute société dont l'associé est une personne physique ou morale.
                    </p>
                  </div>

                  <p className="text-gray-700 mb-3 mt-4">
                    <strong>2. En raison de leurs activités :</strong>
                  </p>
                  <div className="ml-6 space-y-2">
                    <p className="text-gray-700">
                      a) les entreprises publiques, les organismes de l'État ou des collectivités décentralisées qui
                      jouissent de l'autonomie financière et qui se livrent à une activité à caractère industriel ou
                      commercial ;
                    </p>
                    <p className="text-gray-700">
                      b) les personnes morales se livrant à des opérations d'intermédiaire pour l'achat ou la vente
                      d'immeubles ou de fonds de commerce ou qui, habituellement, achètent en leur nom les mêmes biens
                      en vue de les revendre, et les sociétés de crédit foncier ;
                    </p>
                    <p className="text-gray-700">
                      c) les personnes morales qui procèdent au lotissement et à la vente des terrains leur appartenant
                      ;
                    </p>
                    <p className="text-gray-700">
                      d) les personnes morales qui donnent en location un établissement commercial ou industriel muni du
                      mobilier et du matériel nécessaire à son exploitation, que la location comprenne ou non tout ou
                      partie des éléments incorporels du fonds de commerce ou d'industrie ;
                    </p>
                    <p className="text-gray-700">
                      e) les adjudicataires, concessionnaires et fermiers de droits communaux ;
                    </p>
                    <p className="text-gray-700">
                      f) les sociétés d'assurances et de réassurances, quelle que soit leur forme ;
                    </p>
                    <p className="text-gray-700">
                      g) les adjudicataires, concessionnaires et fermiers de droits communaux ;
                    </p>
                    <p className="text-gray-700">
                      h) les personnes morales qui donnent en location un établissement commercial ou industriel muni du
                      mobilier et du matériel nécessaire à son exploitation, que la location comprenne ou non tout ou
                      partie des éléments incorporels du fonds de commerce ou d'industrie ;
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar droite */}
          <div className="lg:w-80 lg:flex-shrink-0">
            {/* Recherche dans le document */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Rechercher dans le document"
                  value={documentSearch}
                  onChange={(e) => setDocumentSearch(e.target.value)}
                  className="pl-10 border-gray-300"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <Button className="w-full action-button action-button-secondary">
                <Print className="w-4 h-4" />
                Imprimer
              </Button>

              <Button className="w-full action-button action-button-secondary">
                <Download className="w-4 h-4" />
                1234
              </Button>

              <Button className="w-full action-button action-button-secondary">
                <Share2 className="w-4 h-4" />
                234
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-primary-lahalex text-white py-4 sm:py-6 mt-8 sm:mt-12">
        <div className="container-responsive">
          <div className="footer-links">
            <span>CONDITIONS GÉNÉRALES DE VENTE ET D'UTILISATION</span>
            <span>POLITIQUES DE CONFIDENTIALITÉS</span>
            <span>COPYRIGHT 2025 LAHALEX TOUS DROITS RÉSERVÉS</span>
            <span>POUR DE L'ASSISTANCE : XXXXXXXXX</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
